import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User as AppUser, WeeklyTimetable, WeeklyPenalties } from '../types';
import { MOCK_USERS, DEFAULT_TIMETABLE } from '../constants';
import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  updateProfile,
  User as FirebaseUser
} from "firebase/auth";
import { getFirestore, doc, setDoc, getDoc, collection, writeBatch } from "firebase/firestore";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBK8q6LBMlIST6b6PVG7hKGGStA9sGtO2U",
  authDomain: "jipjung-8b6f4.firebaseapp.com",
  projectId: "jipjung-8b6f4",
  storageBucket: "jipjung-8b6f4.firebasestorage.app",
  messagingSenderId: "743001702535",
  appId: "1:743001702535:web:23b995b949bb598ec43822",
  measurementId: "G-R3N1R96HQN"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);


interface AuthContextType {
  user: AppUser | null;
  login: (email: string, pass: string) => Promise<boolean>;
  logout: () => Promise<void>;
  register: (name: string, email: string, pass: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser: FirebaseUser | null) => {
      if (firebaseUser) {
        // Find user in mock data first for demo purposes
        const mockUser = MOCK_USERS.find(u => u.email === firebaseUser.email);
        if (mockUser) {
          setUser(mockUser);
          setLoading(false);
          return;
        }

        // Fetch user from Firestore
        const userDocRef = doc(db, "users", firebaseUser.uid);
        const userDocSnap = await getDoc(userDocRef);

        if (userDocSnap.exists()) {
          setUser({ id: firebaseUser.uid, ...userDocSnap.data() } as AppUser);
        } else {
          // Fallback for users that exist in Auth but not Firestore
          const newUser: AppUser = {
            id: firebaseUser.uid,
            name: firebaseUser.displayName || '새 사용자',
            email: firebaseUser.email!,
            rank: 99, 
            weeklyStudyTime: 0,
            membershipStartDate: 'N/A',
            membershipEndDate: 'N/A',
            approved: false,
            canEditTimetable: 0,
            isAdmin: 0,
          };
          setUser(newUser);
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, pass: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, pass);
      return true;
    } catch (error) {
      console.error("Firebase 로그인 오류:", error);
      return false;
    }
  };

  const logout = async () => {
    await signOut(auth);
  };

  const register = async (name: string, email: string, pass: string) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, pass);
      await updateProfile(userCredential.user, { displayName: name });
      const userId = userCredential.user.uid;

      const newUserForDb: Omit<AppUser, 'id'> = {
        name: name,
        email: email,
        rank: 99,
        weeklyStudyTime: 0,
        membershipStartDate: 'N/A',
        membershipEndDate: 'N/A',
        approved: false, // Default to not approved
        canEditTimetable: 0,
        isAdmin: 0, // Default to not an admin
      };
      
      const days = ['월', '화', '수', '목', '금', '토', '일'];
      const initialTimetable: WeeklyTimetable = {};
      const initialPenalties: WeeklyPenalties = {};

      days.forEach(day => {
        DEFAULT_TIMETABLE.forEach(slot => {
            if (slot.isStudy) {
                const key = `${day}-${slot.period}`;
                initialTimetable[key] = true;
                initialPenalties[key] = 0;
            }
        });
      });

      // Use a batch to write all initial data atomically
      const batch = writeBatch(db);

      const userDocRef = doc(db, "users", userId);
      batch.set(userDocRef, newUserForDb);
      
      const timetableDocRef = doc(db, "users", userId, "weeklyplan", "current");
      batch.set(timetableDocRef, initialTimetable);

      const penaltyDocRef = doc(db, "users", userId, "weeklyplan", "penalty");
      batch.set(penaltyDocRef, initialPenalties);

      await batch.commit();

      return true;
    } catch (error) {
      console.error("Firebase 회원가입 오류:", error);
      return false;
    }
  };

  if (loading) {
      return null;
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth는 AuthProvider 내에서 사용해야 합니다.');
  }
  return context;
};