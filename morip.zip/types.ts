
export interface User {
  id: string;
  name: string;
  email: string;
  rank: number;
  weeklyStudyTime: number; // in hours (This might be a cached value, or calculated on fly)
  membershipStartDate: string;
  membershipEndDate: string;
  approved: boolean;
  canEditTimetable: number; // 0: not approved, 1: approved
  isAdmin: number; // 0: user, 1: admin
  
  // Penalty Configuration
  penaltyConfig?: PenaltyConfig;
}

export interface PenaltyConfig {
  method: 'fine' | 'apology' | 'custom'; // 벌금, 반성문, 기타
  amountPerPoint?: number; // 벌금일 경우 금액 (1000 ~ 10000)
  customDutyText?: string; // 기타 의무일 경우 텍스트
}

export interface Ranking {
  rank: number;
  userId: string;
  name: string;
  studyHours: number;
  attendanceRate: number;
}

export interface TimetableSlot {
  period: string;
  time: string;
  isStudy: boolean;
}

export type WeeklyTimetable = {
  [key: string]: boolean;
};

// New Status Type for Admin Management
export type StudyStatus = 'none' | 'attendance' | 'late' | 'absent' | 'off';

export type WeeklyStatus = {
  [key: string]: StudyStatus;
};

export type WeeklyPenalties = {
  [key: string]: number;
};

// For Dashboard - Request Page
export interface RequestItem {
  id: string;
  type: 'urgent_leave' | 'schedule_change' | 'other'; // 긴급휴무, 일정변경, 기타
  details: string;
  reason: string;
  date: string; // 신청 대상 날짜
  requestDate: string; // 신청서 제출일
  status: 'pending' | 'approved' | 'rejected';
  adminNote?: string;
}

// For Dashboard - Penalty Page
export interface PenaltyHistoryItem {
  id: string;
  date: string;
  period: string;
  points: number;
  reason: string; // e.g. "지각", "결석", "이탈"
  status: 'required' | 'pending' | 'approved'; // 요청필요 -> 승인대기(제출완료) -> 승인완료
  proofUrl?: string; // 이미지 URL 등
}
