
import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import AuthModal from './AuthModal';

const BriefcaseIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth={1.8}
    stroke="currentColor"
    className="w-5 h-5"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M8.25 6.75V4.5A1.5 1.5 0 019.75 3h4.5a1.5 1.5 0 011.5 1.5v2.25M3.75 9h16.5M3.75 9a2.25 2.25 0 00-2.25 2.25v7.5A2.25 2.25 0 003.75 21h16.5a2.25 2.25 0 002.25-2.25v-7.5A2.25 2.25 0 0020.25 9M3.75 9h16.5M12 12v4"
    />
  </svg>
);

const Bars3Icon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
  </svg>
);

const XMarkIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
  </svg>
);

const Header: React.FC = () => {
  const { user, logout } = useAuth();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'login' | 'register'>('login');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  const handleOpenModal = (mode: 'login' | 'register') => {
    setModalMode(mode);
    setIsModalOpen(true);
    setIsMobileMenuOpen(false);
  };

  const closeMobileMenu = () => setIsMobileMenuOpen(false);

  const activeLinkStyle = {
    color: '#1E64C8',
  };

  // 페이지 이동 시 모바일 메뉴 닫기
  useEffect(() => {
      closeMobileMenu();
  }, [location]);

  return (
    <>
      <header className="sticky top-0 z-50 bg-white border-b border-brand-light-gray">
        <nav className="
            container mx-auto 
            px-6 md:px-8 lg:px-12 xl:px-[140px] 2xl:px-[180px]
            py-4 
            flex justify-between items-center
        ">

            {/* LEFT - Logo */}
            <div className="flex items-center">
                <Link to="/" className="text-2xl font-extrabold text-brand-navy" onClick={closeMobileMenu}>
                  몰입랩
                </Link>

                {/* Desktop Menu - Visible lg+ (데스크탑에서만 보임) */}
                <div className="hidden lg:flex items-center space-x-8 ml-16">
                    <NavLink to="/" className="font-semibold hover:text-brand-blue text-brand-charcoal"
                        style={({ isActive }) => isActive ? activeLinkStyle : {}}>
                        서비스 소개
                    </NavLink>
                    <NavLink to="/guide" className="font-semibold hover:text-brand-blue text-brand-charcoal"
                        style={({ isActive }) => isActive ? activeLinkStyle : {}}>
                        이용 가이드
                    </NavLink>
                    <NavLink to="/ranking" className="font-semibold hover:text-brand-blue text-brand-charcoal"
                        style={({ isActive }) => isActive ? activeLinkStyle : {}}>
                        몰입 순위
                    </NavLink>

                    {user?.isAdmin === 1 && (
                      <NavLink to="/admin" className="font-semibold hover:text-brand-blue text-brand-charcoal"
                          style={({ isActive }) => isActive ? activeLinkStyle : {}}>
                          관리자 페이지
                      </NavLink>
                    )}
                </div>
            </div>

            {/* RIGHT SIDE - Desktop: Actions, Tablet/Mobile: Hamburger */}
            
            {/* Desktop Right Actions (데스크탑에서만 보임) */}
            <div className="hidden lg:flex items-center space-x-4">
                <Link 
                  to="/mypage" 
                  className="flex items-center space-x-1 text-brand-charcoal hover:text-brand-blue font-semibold"
                >
                  <BriefcaseIcon />
                  <span>근태관리</span>
                </Link>

                {user ? (
                  <>
                    <span className="text-brand-charcoal hidden xl:inline">환영합니다, {user.name}님</span>
                    <button 
                      onClick={logout}
                      className="border border-brand-light-gray text-brand-gray px-4 py-2 rounded-md hover:bg-gray-100 transition-colors text-lg"
                    >
                      로그아웃
                    </button>
                  </>
                ) : (
                  <>
                    <button 
                      onClick={() => handleOpenModal('login')}
                      className="text-brand-blue font-semibold px-4 py-2 rounded-md border border-brand-blue hover:bg-blue-50 transition-colors text-lg"
                    >
                      로그인
                    </button>
                    <button 
                      onClick={() => handleOpenModal('register')}
                      className="bg-brand-blue text-white px-4 py-2 rounded-md hover:shadow-lg hover:opacity-90 transition-all text-lg font-semibold"
                    >
                      회원가입
                    </button>
                  </>
                )}
            </div>

            {/* Mobile Hamburger Button (태블릿/모바일에서만 보임 - 우측에 이것만 나타남) */}
            <button 
                className="lg:hidden text-brand-charcoal focus:outline-none p-1"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                aria-label="메뉴 열기"
            >
                {isMobileMenuOpen ? <XMarkIcon /> : <Bars3Icon />}
            </button>

        </nav>

        {/* Mobile Menu Dropdown - 펼쳐지는 메뉴 */}
        {isMobileMenuOpen && (
            <div className="lg:hidden absolute top-full left-0 w-full bg-white shadow-xl border-t border-gray-100 flex flex-col animate-fade-in-down z-40">
                {/* Container Layout matched with Header Nav for alignment */}
                <div className="container mx-auto px-6 md:px-8 py-6 space-y-6">
                    {/* Navigation Links */}
                    <div className="flex flex-col space-y-4">
                        <NavLink to="/" className="text-lg font-semibold text-brand-charcoal hover:text-brand-blue"
                            style={({ isActive }) => isActive ? activeLinkStyle : {}}>
                            서비스 소개
                        </NavLink>
                        <NavLink to="/guide" className="text-lg font-semibold text-brand-charcoal hover:text-brand-blue"
                            style={({ isActive }) => isActive ? activeLinkStyle : {}}>
                            이용 가이드
                        </NavLink>
                        <NavLink to="/ranking" className="text-lg font-semibold text-brand-charcoal hover:text-brand-blue"
                            style={({ isActive }) => isActive ? activeLinkStyle : {}}>
                            몰입 순위
                        </NavLink>
                        {user?.isAdmin === 1 && (
                            <NavLink to="/admin" className="text-lg font-semibold text-brand-charcoal hover:text-brand-blue"
                                style={({ isActive }) => isActive ? activeLinkStyle : {}}>
                                관리자 페이지
                            </NavLink>
                        )}
                    </div>
                    
                    <hr className="border-gray-100" />
                    
                    {/* Action Buttons */}
                    <div className="flex flex-col space-y-6">
                         <Link 
                            to="/mypage" 
                            className="flex items-center space-x-2 text-lg font-semibold text-brand-charcoal hover:text-brand-blue"
                        >
                            <BriefcaseIcon />
                            <span>근태관리</span>
                        </Link>
                        
                        {user ? (
                             <div className="space-y-4">
                                <p className="text-brand-gray text-sm">환영합니다, <span className="text-brand-navy font-bold text-base">{user.name}</span>님</p>
                                <button 
                                    onClick={() => { logout(); closeMobileMenu(); }}
                                    className="w-full text-center border border-brand-light-gray text-brand-gray py-3 rounded-md hover:bg-gray-50 font-semibold"
                                >
                                    로그아웃
                                </button>
                             </div>
                        ) : (
                            <div className="grid grid-cols-2 gap-4">
                                <button 
                                    onClick={() => handleOpenModal('login')}
                                    className="text-brand-blue font-bold py-3 rounded-md border border-brand-blue hover:bg-blue-50 text-center"
                                >
                                    로그인
                                </button>
                                <button 
                                    onClick={() => handleOpenModal('register')}
                                    className="bg-brand-blue text-white font-bold py-3 rounded-md hover:opacity-90 text-center"
                                >
                                    회원가입
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        )}

        <AuthModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} initialMode={modalMode} />
      </header>
    </>
  );
};

export default Header;
