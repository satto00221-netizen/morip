import React, { useState, useEffect } from 'react';
import { DEFAULT_TIMETABLE } from '../constants';
import { User, WeeklyTimetable } from '../types';

import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, doc, setDoc, getDoc } from 'firebase/firestore';

// Firebase configuration - copied from useAuth.tsx for modularity without creating new files
const firebaseConfig = {
  apiKey: "AIzaSyBK8q6LBMlIST6b6PVG7hKGGStA9sGtO2U",
  authDomain: "jipjung-8b6f4.firebaseapp.com",
  projectId: "jipjung-8b6f4",
  storageBucket: "jipjung-8b6f4.firebasestorage.app",
  messagingSenderId: "743001702535",
  appId: "1:743001702535:web:23b995b949bb598ec43822",
  measurementId: "G-R3N1R96HQN"
};

// Initialize Firebase safely
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app);


interface TimetableFormProps {
    isEditable: boolean;
    user: User;
}

const TimetableForm: React.FC<TimetableFormProps> = ({ isEditable, user }) => {
    const days = ['월', '화', '수', '목', '금', '토', '일'];
    const isMonday = new Date().getDay() === 1;

    const initializeTimetable = (): WeeklyTimetable => {
        const initialTimetable: WeeklyTimetable = {};
        days.forEach(day => {
            DEFAULT_TIMETABLE.forEach(slot => {
                if (slot.isStudy) {
                    initialTimetable[`${day}-${slot.period}`] = true;
                }
            });
        });
        return initialTimetable;
    };

    const [timetable, setTimetable] = useState<WeeklyTimetable>(initializeTimetable);
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

     useEffect(() => {
        const fetchTimetable = async () => {
            if (!user) return;
            setIsLoading(true);
            const timetableRef = doc(db, "users", user.id, "weeklyplan", "current");

            try {
                const docSnap = await getDoc(timetableRef);
                if (docSnap.exists()) {
                    setTimetable(docSnap.data() as WeeklyTimetable);
                } else {
                    // No saved timetable, use the default initialized one
                    setTimetable(initializeTimetable());
                }
            } catch (error) {
                console.error("Error fetching timetable:", error);
                // Fallback to default on error
                setTimetable(initializeTimetable());
            } finally {
                setIsLoading(false);
            }
        };

        fetchTimetable();
    }, [user]);

    const handleCheckboxChange = (day: string, period: string) => {
        const key = `${day}-${period}`;
        setTimetable(prev => ({ ...prev, [key]: !prev[key] }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;

        const timetableRef = doc(db, "users", user.id, "weeklyplan", "current");

        try {
            await setDoc(timetableRef, timetable);
            setIsSubmitted(true);
            setTimeout(() => setIsSubmitted(false), 3000);
        } catch (error) {
            console.error("Failed to save timetable:", error);
            alert("시간표 저장에 실패했습니다.");
        }
    };
    
    if (isLoading) {
        return (
            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200 flex justify-center items-center">
                <h3 className="text-xl font-bold text-brand-navy">주간 시간표를 불러오는 중...</h3>
            </div>
        );
    }

    return (
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-full">
            <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center">
                <div>
                    <h3 className="text-lg font-bold text-brand-navy">주간 스케줄 관리</h3>
                    <p className="text-sm text-slate-500 mt-1">이번 주 스터디 일정을 관리합니다. (월요일 24:00 마감)</p>
                </div>
                {!isEditable && (
                    <span className="mt-2 sm:mt-0 px-3 py-1 bg-red-50 text-red-600 text-xs font-bold rounded-full border border-red-100">
                        수정 불가 (마감됨)
                    </span>
                )}
                {isEditable && !isMonday && user.canEditTimetable === 1 && (
                     <span className="mt-2 sm:mt-0 px-3 py-1 bg-blue-50 text-blue-600 text-xs font-bold rounded-full border border-blue-100">
                        관리자 승인: 수정 가능
                    </span>
                )}
            </div>

            <form onSubmit={handleSubmit}>
                <div className="overflow-x-auto">
                    <table className="min-w-full border-collapse text-center table-fixed text-sm">
                        <thead>
                            <tr className="bg-slate-50 text-slate-600">
                                <th className="p-3 font-bold border border-slate-200 w-[100px]">교시</th>
                                {days.map(day => (
                                    <th key={day} className="p-3 font-bold border border-slate-200">{day}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {DEFAULT_TIMETABLE.map(slot => (
                                <tr key={slot.period} className="border-t border-slate-200 hover:bg-slate-50/50 transition-colors">
                                    {slot.isStudy ? (
                                        <>
                                            <td className="p-2 font-bold text-slate-700 border border-slate-200 bg-slate-50/80">
                                                {slot.period}
                                                <br />
                                                <span className="text-[10px] text-slate-400 font-normal">{slot.time}</span>
                                            </td>
                                            {days.map(day => (
                                                <td key={`${day}-${slot.period}`} className="p-2 border border-slate-200 align-middle">
                                                    {isEditable ? (
                                                        <input
                                                            type="checkbox"
                                                            checked={!!timetable[`${day}-${slot.period}`]}
                                                            onChange={() => handleCheckboxChange(day, slot.period)}
                                                            className="h-5 w-5 rounded border-gray-300 text-brand-blue focus:ring-brand-blue cursor-pointer"
                                                        />
                                                    ) : (
                                                        !!timetable[`${day}-${slot.period}`] && (
                                                            <div className="h-5 w-5 mx-auto rounded bg-blue-100 flex items-center justify-center">
                                                                <svg className="w-3.5 h-3.5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3">
                                                                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                                                </svg>
                                                            </div>
                                                        )
                                                    )}
                                                </td>
                                            ))}
                                        </>
                                    ) : (
                                        <td colSpan={8} className="p-2 font-bold text-blue-600 bg-blue-50/50 border border-slate-200 text-xs">
                                            {slot.period} ({slot.time})
                                        </td>
                                    )}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <div className="mt-6 flex justify-end">
                    <button 
                        type="submit" 
                        className="bg-brand-navy text-white px-6 py-2.5 rounded-lg shadow-md hover:bg-opacity-90 transition-all font-bold text-sm disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none"
                        disabled={!isEditable}
                    >
                        {isSubmitted ? '저장 완료!' : '스케줄 저장하기'}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default TimetableForm;