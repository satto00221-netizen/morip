import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-gray-300">
      <div className="container mx-auto px-6 py-10">
        <div className="flex flex-col md:flex-row justify-between items-start">
          <div className="mb-6 md:mb-0">
            <h3 className="text-xl font-bold text-white">몰입랩</h3>
            <p className="text-sm mt-1 text-gray-400">몰입이 우리의 일입니다.</p>
          </div>
          <div className="flex space-x-6 text-sm">
            <a href="#" className="text-gray-300 hover:text-white transition-colors">서비스 이용약관</a>
            <a href="#" className="text-gray-300 hover:text-white transition-colors">개인정보 처리방침</a>
            <a href="#" className="text-gray-300 hover:text-white transition-colors">문의하기</a>
          </div>
        </div>

        <div className="mt-8 border-t border-gray-700 pt-6 text-sm text-gray-400">
          <div className="space-y-2">
              <p>
                  <span>대표: 변성수</span>
                  <span className="mx-2">|</span>
                  <span>사업자등록번호 : 679-26-01843</span>
                   <span className="mx-2">|</span>
                  <span>통신판매업신고번호 : 2025-대구수성구-0560</span>
              </p>
              <p>주소: 대구광역시 수성구 수성로 367-2, 4층 413호</p>
              <p>E-mail: <a href="mailto:satto00221@gmail.com" className="text-gray-300 hover:text-white">satto00221@gmail.com</a></p>
          </div>
          <p className="mt-8 text-xs text-gray-500 text-center">
            © {new Date().getFullYear()} morip lab. 모든 권리 보유.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;