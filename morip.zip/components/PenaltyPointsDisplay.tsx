
import React, { useState, useEffect } from 'react';
import { User, WeeklyStatus } from '../types';
import { DEFAULT_TIMETABLE } from '../constants';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, doc, getDoc } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBK8q6LBMlIST6b6PVG7hKGGStA9sGtO2U",
  authDomain: "jipjung-8b6f4.firebaseapp.com",
  projectId: "jipjung-8b6f4",
  storageBucket: "jipjung-8b6f4.firebasestorage.app",
  messagingSenderId: "743001702535",
  appId: "1:743001702535:web:23b995b949bb598ec43822",
  measurementId: "G-R3N1R96HQN"
};

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app);

interface PenaltyPointsDisplayProps {
    user: User;
}

const PenaltyPointsDisplay: React.FC<PenaltyPointsDisplayProps> = ({ user }) => {
    const [statuses, setStatuses] = useState<WeeklyStatus>({});
    const [totalPoints, setTotalPoints] = useState(0);
    const [isLoading, setIsLoading] = useState(true);
    const days = ['월', '화', '수', '목', '금', '토', '일'];

    useEffect(() => {
        const fetchPenalties = async () => {
            if (!user) return;
            setIsLoading(true);
            // Updated path to fetch status data
            const statusRef = doc(db, "users", user.id, "weeklyplan", "status");

            try {
                const docSnap = await getDoc(statusRef);
                if (docSnap.exists()) {
                    const data = docSnap.data() as WeeklyStatus;
                    setStatuses(data);
                    
                    let points = 0;
                    Object.values(data).forEach(s => {
                        if (s === 'late') points += 1;
                        if (s === 'absent') points += 2;
                    });
                    setTotalPoints(points);
                } else {
                    setStatuses({});
                    setTotalPoints(0);
                }
            } catch (error) {
                console.error("Error fetching penalty points:", error);
                setStatuses({});
                setTotalPoints(0);
            } finally {
                setIsLoading(false);
            }
        };

        fetchPenalties();
    }, [user]);

    if (isLoading) {
        return (
            <div className="bg-white p-6 rounded-lg shadow-lg">
                <h3 className="text-xl font-semibold text-brand-navy mb-4">주간 벌점 현황</h3>
                <p className="text-brand-gray">정보를 불러오는 중입니다...</p>
            </div>
        );
    }
    
    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <h3 className="text-xl font-semibold text-brand-navy mb-4">주간 벌점 현황</h3>
            <div className="overflow-x-auto">
                <table className="min-w-full border-collapse text-center table-fixed text-sm">
                    <thead>
                        <tr className="bg-gray-100">
                            <th className="p-2 font-semibold text-brand-charcoal border border-brand-light-gray w-[25%]">교시</th>
                            {days.map(day => (
                                <th key={day} className="p-2 font-semibold text-brand-charcoal border border-brand-light-gray">{day}</th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {DEFAULT_TIMETABLE.filter(s => s.isStudy).map(slot => (
                            <tr key={slot.period}>
                                <td className="p-2 font-semibold text-brand-navy border border-brand-light-gray bg-gray-50">{slot.period}</td>
                                {days.map(day => {
                                    const key = `${day}-${slot.period}`;
                                    const status = statuses[key];
                                    let display = '';
                                    let colorClass = '';
                                    
                                    if (status === 'late') { display = '지각'; colorClass = 'text-yellow-600 font-bold'; }
                                    else if (status === 'absent') { display = '결석'; colorClass = 'text-red-600 font-bold'; }
                                    else if (status === 'attendance') { display = '출석'; colorClass = 'text-green-600'; }

                                    return (
                                        <td key={key} className="p-2 border border-brand-light-gray text-xs">
                                            <span className={colorClass}>{display}</span>
                                        </td>
                                    );
                                })}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div className="mt-4 text-right">
                <span className="font-semibold text-brand-gray">주간 총 벌점: </span>
                <span className="font-bold text-red-600 text-lg">{totalPoints}점</span>
            </div>
        </div>
    );
};

export default PenaltyPointsDisplay;
