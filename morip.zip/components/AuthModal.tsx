import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'register';
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, initialMode = 'login' }) => {
  const [mode, setMode] = useState(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const { login, register } = useAuth();

  useEffect(() => {
    setMode(initialMode);
    // Reset fields when mode changes
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setName('');
    setError('');
  }, [initialMode, isOpen]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const success = await login(email, password);
    if (success) {
      onClose();
    } else {
      setError('이메일 또는 비밀번호가 잘못되었습니다.');
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError('비밀번호가 일치하지 않습니다.');
      return;
    }
    setError('');
    const success = await register(name, email, password);
    if (success) {
      onClose(); // On success, just close the modal. User is now logged in.
    } else {
      setError('회원가입에 실패했습니다. 이미 사용 중인 이메일일 수 있습니다.');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-xl p-8 w-full max-w-md" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-brand-navy">{mode === 'login' ? '로그인' : '회원가입'}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800 text-2xl leading-none">&times;</button>
        </div>
        
        {error && <div className="bg-red-100 text-red-700 p-3 rounded-md mb-4 text-sm">{error}</div>}
        
        {mode === 'login' ? (
          <form onSubmit={handleLogin}>
            <div className="mb-4">
              <label className="block text-gray-700 mb-2" htmlFor="login-email">이메일</label>
              <input type="email" id="login-email" value={email} onChange={e => setEmail(e.target.value)} className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue" required />
            </div>
            <div className="mb-6">
              <label className="block text-gray-700 mb-2" htmlFor="login-password">비밀번호</label>
              <input type="password" id="login-password" value={password} onChange={e => setPassword(e.target.value)} className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue" required />
            </div>
            <button type="submit" className="w-full bg-gradient-to-r from-gradient-start to-gradient-end text-white py-2 rounded-md hover:shadow-lg transition-shadow font-semibold">로그인</button>
            <p className="text-center text-sm text-gray-600 mt-4">
              계정이 없으신가요? <button type="button" onClick={() => setMode('register')} className="text-brand-blue hover:underline font-semibold">회원가입</button>
            </p>
          </form>
        ) : (
          <form onSubmit={handleRegister}>
             <div className="mb-4">
              <label className="block text-gray-700 mb-2" htmlFor="reg-name">이름</label>
              <input type="text" id="reg-name" value={name} onChange={e => setName(e.target.value)} className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue" required />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 mb-2" htmlFor="reg-email">이메일</label>
              <input type="email" id="reg-email" value={email} onChange={e => setEmail(e.target.value)} className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue" required />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 mb-2" htmlFor="reg-password">비밀번호</label>
              <input type="password" id="reg-password" value={password} onChange={e => setPassword(e.target.value)} className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue" required />
            </div>
             <div className="mb-6">
              <label className="block text-gray-700 mb-2" htmlFor="reg-confirm-password">비밀번호 재확인</label>
              <input type="password" id="reg-confirm-password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue" required />
            </div>
            <button type="submit" className="w-full bg-gradient-to-r from-gradient-start to-gradient-end text-white py-2 rounded-md hover:shadow-lg transition-shadow font-semibold">회원가입</button>
            <p className="text-center text-sm text-gray-600 mt-4">
              이미 계정이 있으신가요? <button type="button" onClick={() => setMode('login')} className="text-brand-blue hover:underline font-semibold">로그인</button>
            </p>
          </form>
        )}
      </div>
    </div>
  );
};

export default AuthModal;
