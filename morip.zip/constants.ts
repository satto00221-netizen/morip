import { User, Ranking, TimetableSlot } from './types';

export const MOCK_USERS: User[] = [
  { id: 'johndoe', name: 'John Doe', email: 'john@example.com', rank: 5, weeklyStudyTime: 12, membershipStartDate: '2025.11.10', membershipEndDate: '2025.12.30', approved: true, canEditTimetable: 0, isAdmin: 0 },
  { id: 'janesmith', name: 'Jane Smith', email: 'jane@example.com', rank: 1, weeklyStudyTime: 25, membershipStartDate: '2025.11.10', membershipEndDate: '2025.12.30', approved: true, canEditTimetable: 0, isAdmin: 1 },
];

export const MOCK_RANKINGS: Ranking[] = [
    { rank: 1, userId: 'user003', name: '김민준', studyHours: 55.5, attendanceRate: 100 },
    { rank: 2, userId: 'user007', name: '이서연', studyHours: 52.0, attendanceRate: 98 },
    { rank: 3, userId: 'user001', name: '박도윤', studyHours: 51.5, attendanceRate: 99 },
    { rank: 4, userId: 'user012', name: '최아린', studyHours: 49.0, attendanceRate: 100 },
    { rank: 5, userId: 'janesmith', name: 'Jane Smith', studyHours: 48.2, attendanceRate: 95 },
    { rank: 6, userId: 'johndoe', name: 'John Doe', studyHours: 45.0, attendanceRate: 92 },
    { rank: 7, userId: 'user005', name: '정하윤', studyHours: 43.8, attendanceRate: 97 },
    { rank: 8, userId: 'user009', name: '윤지호', studyHours: 42.1, attendanceRate: 90 },
];

export const DEFAULT_TIMETABLE: TimetableSlot[] = [
  { period: '1교시', time: '08:00–09:10', isStudy: true },
  { period: '2교시', time: '09:25–10:35', isStudy: true },
  { period: '3교시', time: '10:50–12:00', isStudy: true },
  { period: '점심시간', time: '12:00–13:30', isStudy: false },
  { period: '4교시', time: '13:30–14:40', isStudy: true },
  { period: '5교시', time: '14:55–16:05', isStudy: true },
  { period: '6교시', time: '16:20–17:30', isStudy: true },
  { period: '저녁시간', time: '17:30–19:00', isStudy: false },
  { period: '7교시', time: '19:00–20:10', isStudy: true },
  { period: '8교시', time: '20:25–21:35', isStudy: true },
  { period: '9교시', time: '21:50–23:00', isStudy: true },
];