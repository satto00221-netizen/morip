import React from 'react';

const GuidePage: React.FC = () => {
    return (
        <div className="bg-brand-bg py-16">
            <div className="container mx-auto px-6">
                <div className="max-w-4xl mx-auto">
                    <h1 className="text-4xl font-bold text-brand-navy text-center mb-4">이용 가이드</h1>
                    <p className="text-xl text-brand-gray text-center mb-12">몰입랩 시스템을 효과적으로 사용하는 방법입니다.</p>
                    
                    <div className="space-y-8">
                        <div className="p-8 rounded-lg shadow-lg bg-white">
                            <h2 className="text-2xl font-semibold text-brand-navy mb-4">1. 회원가입</h2>
                            <p className="text-brand-gray leading-relaxed">
                                웹사이트 우측 상단의 '회원가입' 버튼을 통해 가입을 진행합니다. 가입 시 이름, 이메일, 비밀번호를 정확히 입력해주세요.
                                가입 즉시 모든 서비스를 이용할 수 있습니다.
                            </p>
                        </div>

                        <div className="p-8 rounded-lg shadow-lg bg-white">
                            <h2 className="text-2xl font-semibold text-brand-navy mb-4">2. 주간 시간표 제출</h2>
                            <p className="text-brand-gray leading-relaxed">
                                로그-인 후 '마이페이지'로 이동하여 주간 시간표를 제출해야 합니다. 매주 월요일 24:00까지 다음 주의 스터디 참여 여부를 각 교시별로 체크하여 제출해주세요.
                                시간표를 제출해야 해당 주의 스터디 세션에 참여할 수 있으며, 출석률 산정의 기준이 됩니다.
                            </p>
                        </div>

                        <div className="p-8 rounded-lg shadow-lg bg-white">
                            <h2 className="text-2xl font-semibold text-brand-navy mb-4">3. Microsoft Teams 접속</h2>
                            <p className="text-brand-gray leading-relaxed">
                                모든 스터디 세션은 Microsoft Teams를 통해 진행됩니다. 세션 시작 10분 전, 공지사항에 안내된 링크를 통해 접속해주세요.
                                접속 시에는 반드시 웹캠을 켜고, 본인의 얼굴과 상반신이 잘 보이도록 각도를 조절해야 합니다. 마이크는 기본적으로 음소거 상태를 유지합니다.
                            </p>
                        </div>
                        
                        <div className="p-8 rounded-lg shadow-lg bg-white">
                            <h2 className="text-2xl font-semibold text-brand-navy mb-4">4. 랭킹 및 페널티</h2>
                            <p className="text-brand-gray leading-relaxed">
                                '공부 랭킹' 페이지에서 주간 학습 시간과 출석률을 기준으로 한 순위를 확인할 수 있습니다.
                                무단 결석, 잦은 지각, 웹캠 비활성화 등 규정 위반 시 페널티가 부과되며, 이는 랭킹 및 멤버십 자격에 영향을 줄 수 있습니다.
                                성실한 참여를 통해 건강한 스터디 문화를 함께 만들어갑시다.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default GuidePage;