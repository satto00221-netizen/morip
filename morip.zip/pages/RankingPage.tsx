import React from 'react';
import { MOCK_RANKINGS } from '../constants';

const RankingPage: React.FC = () => {
  return (
    <div className="bg-brand-bg min-h-screen py-16">
      <div className="container mx-auto px-6">
        <h1 className="text-4xl font-bold text-brand-navy text-center mb-12">몰입 순위</h1>
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-xl overflow-hidden border border-brand-light-gray">
          <div className="overflow-x-auto">
            <table className="min-w-full align-middle">
              <thead className="bg-gray-100 text-brand-charcoal">
                <tr>
                  <th className="p-4 text-left font-semibold">순위</th>
                  <th className="p-4 text-left font-semibold">이름</th>
                  <th className="p-4 text-left font-semibold">주간 총 몰입 시간</th>
                  <th className="p-4 text-left font-semibold">출석률</th>
                </tr>
              </thead>
              <tbody>
                {MOCK_RANKINGS.map((entry, index) => (
                  <tr key={entry.userId} 
                      className={`border-t border-brand-light-gray transition-colors
                        ${index < 3 ? 'bg-blue-50' : 'hover:bg-blue-50'}
                      `}>
                    <td className="p-4 font-bold text-brand-navy text-lg text-center">
                      {entry.rank === 1 ? '🥇' : entry.rank === 2 ? '🥈' : entry.rank === 3 ? '🥉' : entry.rank}
                    </td>
                    <td className="p-4 text-brand-gray font-medium">{entry.name}</td>
                    <td className="p-4 text-brand-gray">{entry.studyHours.toFixed(1)} 시간</td>
                    <td className="p-4 text-brand-gray">
                      <div className="flex items-center">
                        <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
                          <div className="bg-brand-blue h-2.5 rounded-full" style={{ width: `${entry.attendanceRate}%` }}></div>
                        </div>
                        <span>{entry.attendanceRate}%</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RankingPage;