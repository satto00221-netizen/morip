
import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../hooks/useAuth';
import TimetableForm from '../components/TimetableForm';
import { User, PenaltyConfig, RequestItem, PenaltyHistoryItem, WeeklyStatus, StudyStatus, WeeklyTimetable } from '../types';
import { getFirestore, doc, updateDoc, collection, addDoc, getDocs, query, where, orderBy, getDoc } from 'firebase/firestore';
import { DEFAULT_TIMETABLE } from '../constants';

const db = getFirestore();

// --- Icons ---
const HomeIcon = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>;
const CalendarIcon = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>;
const ClipboardIcon = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>;
const HandRaisedIcon = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 11.5V14m0-2.5v-6a1.5 1.5 0 113 0m-3 6a1.5 1.5 0 00-3 0v2a7.5 7.5 0 0015 0v-5a1.5 1.5 0 00-3 0m-6-3V11m0-5.5v-1a1.5 1.5 0 013 0v1m0 0V11m0-5.5a1.5 1.5 0 013 0v3m0 0V11" /></svg>;

// --- Helper: Calculate Hours ---
// 1 slot = 70 minutes = 70/60 hours
const SLOT_DURATION_MIN = 70;

// --- Sub Components ---

// 1. Dashboard Home
const DashboardHome: React.FC<{ user: User }> = ({ user }) => {
    const today = new Date();
    const dateStr = `${today.getFullYear()}년 ${today.getMonth() + 1}월 ${today.getDate()}일`;
    const dayName = ['일', '월', '화', '수', '목', '금', '토'][today.getDay()];

    // State for Stats
    const [scheduledHours, setScheduledHours] = useState(0);
    const [approvedHours, setApprovedHours] = useState(0);
    const [currentPenalty, setCurrentPenalty] = useState(0);
    
    // Mock Data for Graphs (Legacy)
    const weeklyGrowthData = [10, 25, 40, 35, 50, 60, 55]; 
    const attendanceData = [95, 92, 98, 88, 96, 100, 99]; 

    useEffect(() => {
        const fetchWeeklyData = async () => {
            try {
                const timetableRef = doc(db, "users", user.id, "weeklyplan", "current");
                const statusRef = doc(db, "users", user.id, "weeklyplan", "status");
                
                const [timetableSnap, statusSnap] = await Promise.all([getDoc(timetableRef), getDoc(statusRef)]);
                
                // 1. Calculate Scheduled Hours
                let checkedCount = 0;
                if (timetableSnap.exists()) {
                    const timetable = timetableSnap.data() as WeeklyTimetable;
                    checkedCount = Object.values(timetable).filter(v => v === true).length;
                }
                setScheduledHours((checkedCount * SLOT_DURATION_MIN) / 60);

                // 2. Calculate Approved Hours & Penalties
                let approvedCount = 0;
                let penaltyPoints = 0;
                if (statusSnap.exists()) {
                    const status = statusSnap.data() as WeeklyStatus;
                    Object.values(status).forEach(s => {
                        if (s === 'attendance') approvedCount++;
                        if (s === 'late') penaltyPoints += 1;
                        if (s === 'absent') penaltyPoints += 2;
                    });
                }
                setApprovedHours((approvedCount * SLOT_DURATION_MIN) / 60);
                setCurrentPenalty(penaltyPoints);

            } catch (error) {
                console.error("Error fetching dashboard stats:", error);
            }
        };

        fetchWeeklyData();
    }, [user]);

    return (
        <div className="space-y-6 animate-fade-in">
            {/* Top Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end border-b border-gray-200 pb-4 gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-slate-800">{dateStr} ({dayName})</h2>
                    <p className="text-slate-500 text-sm mt-1">오늘도 몰입하는 하루 되세요.</p>
                </div>
                <div className="bg-white px-4 py-2 rounded-full border border-gray-200 shadow-sm text-sm font-medium text-slate-600 whitespace-nowrap">
                   총 직원수(멤버): <span className="text-brand-blue font-bold">1</span>명
                </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <StatsCard 
                    title="주간 예정 근로(학습)" 
                    value={`${scheduledHours.toFixed(1)}H`} 
                    subValue={`목표 달성률 ${scheduledHours > 0 ? Math.min(100, Math.round((approvedHours/scheduledHours)*100)) : 0}%`} 
                    color="blue" 
                />
                <StatsCard 
                    title="승인된 근로(학습)" 
                    value={`${approvedHours.toFixed(1)}H`} 
                    subValue="관리자 승인 완료" 
                    color="green" 
                />
                <StatsCard 
                    title="일평균 학습" 
                    value={`${(approvedHours / 7).toFixed(1)}H`} 
                    subValue={`예정 ${(scheduledHours/7).toFixed(1)}H`} 
                    color="indigo" 
                />
                <StatsCard 
                    title="주간 벌점" 
                    value={`${currentPenalty}점`} 
                    subValue={currentPenalty === 0 ? "이번주 경고 없음" : "주의 필요"} 
                    color="red" 
                />
            </div>

            {/* Main Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
                {/* Left: Graphs */}
                <div className="lg:col-span-2 space-y-6">
                     <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="font-bold text-slate-700">사용자 성장 그래프</h3>
                            <button className="text-xs bg-slate-100 hover:bg-slate-200 px-3 py-1 rounded text-slate-600 transition-colors">월간 리포트 보기</button>
                        </div>
                        {/* Simple Line Chart Viz */}
                        <div className="h-48 flex items-end justify-between space-x-2 px-2">
                            {weeklyGrowthData.map((h, i) => (
                                <div key={i} className="flex flex-col items-center flex-1 group">
                                    <div className="relative w-full flex justify-center">
                                         <div className="absolute bottom-0 w-0.5 bg-blue-100 h-48 z-0"></div>
                                         <div 
                                            style={{ height: `${h * 2}px` }} 
                                            className="w-full max-w-[30px] bg-blue-500 rounded-t-sm z-10 group-hover:bg-blue-600 transition-all relative"
                                         >
                                            <span className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-xs text-blue-600 opacity-0 group-hover:opacity-100 font-bold">{h}h</span>
                                         </div>
                                    </div>
                                    <span className="text-xs text-gray-400 mt-2">W-{7-i}</span>
                                </div>
                            ))}
                        </div>
                    </div>

                     <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="font-bold text-slate-700">주차별 출석률 변화</h3>
                        </div>
                        {/* Simple Line Chart Simulation */}
                         <div className="h-40 relative flex items-end px-4 border-l border-b border-gray-100">
                             <svg className="absolute inset-0 h-full w-full overflow-visible">
                                <polyline 
                                    fill="none" 
                                    stroke="#1E64C8" 
                                    strokeWidth="3" 
                                    points={attendanceData.map((rate, i) => `${(i * (100 / (attendanceData.length - 1)))}%,${100 - rate + 20}`).join(' ')} 
                                    vectorEffect="non-scaling-stroke"
                                />
                             </svg>
                              {attendanceData.map((rate, i) => (
                                <div key={i} className="flex-1 flex justify-center relative h-full">
                                    <div className="absolute bottom-0 text-xs text-gray-400 translate-y-4">W-{7-i}</div>
                                </div>
                            ))}
                         </div>
                    </div>
                </div>

                {/* Right: Calendar */}
                <div className="lg:col-span-1">
                    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 h-full flex flex-col">
                        <h3 className="font-bold text-slate-700 mb-4">2025년 11월</h3>
                        <div className="grid grid-cols-7 gap-1 text-center text-xs font-medium text-slate-400 mb-2">
                            <div>일</div><div>월</div><div>화</div><div>수</div><div>목</div><div>금</div><div>토</div>
                        </div>
                        <div className="grid grid-cols-7 gap-1 flex-grow content-start">
                            {/* Mock Calendar Days */}
                            {Array.from({ length: 30 }).map((_, i) => {
                                const day = i + 1;
                                const isToday = day === today.getDate();
                                // For demo, randomized hours. In real app, fetch from history.
                                const studyHours = Math.floor(Math.random() * 6); 
                                return (
                                    <div key={i} className={`aspect-square rounded-lg border ${isToday ? 'border-brand-blue bg-blue-50' : 'border-gray-100'} p-1 flex flex-col justify-between items-center hover:shadow-md transition-shadow`}>
                                        <span className={`${isToday ? 'text-brand-blue font-bold' : 'text-slate-600'}`}>{day}</span>
                                        {studyHours > 0 && (
                                            <span className="text-[10px] bg-green-100 text-green-700 px-1.5 rounded-full">{studyHours}h</span>
                                        )}
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const StatsCard: React.FC<{ title: string, value: string, subValue: string, color: string }> = ({ title, value, subValue, color }) => {
    const colorClasses: Record<string, string> = {
        blue: 'text-blue-600',
        green: 'text-emerald-600',
        indigo: 'text-indigo-600',
        red: 'text-rose-600',
    };
    return (
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <h4 className="text-sm font-medium text-slate-500 mb-2">{title}</h4>
            <div className={`text-3xl font-extrabold ${colorClasses[color] || 'text-slate-800'}`}>{value}</div>
            <p className="text-xs text-slate-400 mt-2">{subValue}</p>
        </div>
    );
};


// 2. Dashboard Schedule
const DashboardSchedule: React.FC<{ user: User, refreshUser: () => void }> = ({ user, refreshUser }) => {
    const [penaltyConfig, setPenaltyConfig] = useState<PenaltyConfig>(user.penaltyConfig || { method: 'fine', amountPerPoint: 3000 });
    const [isSaving, setIsSaving] = useState(false);
    const db = getFirestore();

    const handleConfigChange = (field: keyof PenaltyConfig, value: any) => {
        setPenaltyConfig(prev => ({ ...prev, [field]: value }));
    };

    const saveConfig = async () => {
        setIsSaving(true);
        try {
            await updateDoc(doc(db, 'users', user.id), {
                penaltyConfig: penaltyConfig
            });
            refreshUser(); // Refetch user to sync state
            alert("벌점 수행 방식이 저장되었습니다.");
        } catch (e) {
            console.error(e);
            alert("저장 실패");
        } finally {
            setIsSaving(false);
        }
    };

    const now = new Date();
    const dayOfWeek = now.getDay();
    // 월요일(1) 이거나 관리자 승인이 있으면 수정 가능
    const isEditable = dayOfWeek === 1 || user.canEditTimetable === 1;

    return (
        <div className="flex flex-col xl:flex-row gap-6 animate-fade-in">
            {/* Main Timetable (Reusing existing component) */}
            <div className="flex-grow">
                <TimetableForm isEditable={isEditable} user={user} />
            </div>

            {/* Penalty Config Sidebar */}
            <div className="w-full xl:w-96 space-y-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 sticky top-6">
                    <h3 className="text-lg font-bold text-brand-navy mb-4 flex items-center">
                        <svg className="w-5 h-5 mr-2 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                        벌점 수행 방식 설정
                    </h3>
                    <p className="text-sm text-slate-500 mb-6">
                        벌점이 발생했을 때 어떻게 책임을 질 것인지 미리 설정합니다.
                    </p>

                    <div className={`space-y-4 ${!isEditable ? 'opacity-60 pointer-events-none' : ''}`}>
                        <label className={`flex items-start p-3 rounded-lg border cursor-pointer transition-all ${penaltyConfig.method === 'fine' ? 'border-brand-blue bg-blue-50 ring-1 ring-brand-blue' : 'border-gray-200 hover:bg-gray-50'}`}>
                            <input 
                                type="radio" 
                                name="method" 
                                className="mt-1 text-brand-blue focus:ring-brand-blue"
                                checked={penaltyConfig.method === 'fine'} 
                                onChange={() => handleConfigChange('method', 'fine')}
                                disabled={!isEditable}
                            />
                            <div className="ml-3">
                                <span className="block text-sm font-bold text-slate-700">벌금 납입</span>
                                <span className="block text-xs text-slate-500 mt-1">관대함 방지를 위해 벌금 강도를 높게 설정하십시오.</span>
                            </div>
                        </label>

                        {penaltyConfig.method === 'fine' && (
                            <div className="pl-8">
                                <label className="block text-xs font-semibold text-slate-600 mb-1">1점당 금액</label>
                                <select 
                                    value={penaltyConfig.amountPerPoint} 
                                    onChange={(e) => handleConfigChange('amountPerPoint', Number(e.target.value))}
                                    className="w-full p-2 text-sm border border-gray-300 rounded-md focus:ring-brand-blue focus:border-brand-blue"
                                    disabled={!isEditable}
                                >
                                    {[1000, 2000, 3000, 5000, 10000].map(amt => (
                                        <option key={amt} value={amt}>{amt.toLocaleString()}원</option>
                                    ))}
                                </select>
                            </div>
                        )}

                        <label className={`flex items-start p-3 rounded-lg border cursor-pointer transition-all ${penaltyConfig.method === 'apology' ? 'border-brand-blue bg-blue-50 ring-1 ring-brand-blue' : 'border-gray-200 hover:bg-gray-50'}`}>
                            <input 
                                type="radio" 
                                name="method" 
                                className="mt-1 text-brand-blue focus:ring-brand-blue"
                                checked={penaltyConfig.method === 'apology'} 
                                onChange={() => handleConfigChange('method', 'apology')}
                                disabled={!isEditable}
                            />
                            <div className="ml-3">
                                <span className="block text-sm font-bold text-slate-700">반성문 제출</span>
                                <span className="block text-xs text-slate-500 mt-1">정해진 양식에 맞춰 자필 반성문을 작성하고 사진을 찍어 업로드합니다.</span>
                            </div>
                        </label>

                         <label className={`flex items-start p-3 rounded-lg border cursor-pointer transition-all ${penaltyConfig.method === 'custom' ? 'border-brand-blue bg-blue-50 ring-1 ring-brand-blue' : 'border-gray-200 hover:bg-gray-50'}`}>
                            <input 
                                type="radio" 
                                name="method" 
                                className="mt-1 text-brand-blue focus:ring-brand-blue"
                                checked={penaltyConfig.method === 'custom'} 
                                onChange={() => handleConfigChange('method', 'custom')}
                                disabled={!isEditable}
                            />
                            <div className="ml-3 w-full">
                                <span className="block text-sm font-bold text-slate-700">기타 의무</span>
                                <span className="block text-xs text-slate-500 mt-1 mb-2">본인이 직접 정한 페널티를 수행합니다.</span>
                                {penaltyConfig.method === 'custom' && (
                                    <input 
                                        type="text" 
                                        placeholder="예: 3km 러닝 인증샷" 
                                        value={penaltyConfig.customDutyText || ''}
                                        onChange={(e) => handleConfigChange('customDutyText', e.target.value)}
                                        className="w-full p-2 text-sm border border-brand-blue/30 rounded bg-white"
                                        disabled={!isEditable}
                                    />
                                )}
                            </div>
                        </label>
                    </div>

                    <button 
                        onClick={saveConfig} 
                        disabled={isSaving || !isEditable}
                        className="w-full mt-6 bg-brand-navy text-white py-3 rounded-lg font-bold text-sm hover:bg-opacity-90 transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {!isEditable ? '수정 권한 없음' : isSaving ? '저장 중...' : '설정 저장하기'}
                    </button>
                </div>
            </div>
        </div>
    );
};


// 3. Dashboard Penalty History
const DashboardPenalty: React.FC<{ user: User }> = ({ user }) => {
    const [penalties, setPenalties] = useState<PenaltyHistoryItem[]>([]);
    const [selectedPenalty, setSelectedPenalty] = useState<PenaltyHistoryItem | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);

    useEffect(() => {
        const fetchCurrentStatus = async () => {
            // Read from "status" doc instead of "penalty" doc
            const statusRef = doc(db, "users", user.id, "weeklyplan", "status");
            const snap = await getDoc(statusRef);
            if(snap.exists()) {
                const data = snap.data() as WeeklyStatus;
                const list: PenaltyHistoryItem[] = [];
                const today = new Date().toISOString().split('T')[0];
                
                Object.entries(data).forEach(([key, status], idx) => {
                    // Only showing items that incur a penalty (Late or Absent)
                    let points = 0;
                    let reason = '';
                    
                    if (status === 'late') {
                        points = 1;
                        reason = '지각';
                    } else if (status === 'absent') {
                        points = 2;
                        reason = '결석';
                    }

                    if(points > 0) {
                        const [day, period] = key.split('-');
                        list.push({
                            id: `p-${idx}`,
                            date: today, // Mock date
                            period: `${day}요일 ${period}`,
                            points: points,
                            reason: reason,
                            status: 'required' // Default status for demo
                        });
                    }
                });
                setPenalties(list);
            }
        };
        fetchCurrentStatus();
    }, [user.id]);

    const openRequestModal = (item: PenaltyHistoryItem) => {
        setSelectedPenalty(item);
        setIsModalOpen(true);
    };

    const handlePenaltySubmit = (proofFile: File | null) => {
        // Mock submission
        if (selectedPenalty) {
            setPenalties(prev => prev.map(p => p.id === selectedPenalty.id ? { ...p, status: 'pending' } : p));
            setIsModalOpen(false);
            alert("증빙 자료가 제출되었습니다. 관리자 승인을 기다려주세요.");
        }
    };

    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden animate-fade-in">
            <div className="p-6 border-b border-gray-200 flex justify-between items-center">
                <h3 className="text-lg font-bold text-brand-navy">상벌 이력 및 처리</h3>
                <div className="text-sm text-slate-500">
                    누적 벌점: <span className="text-red-600 font-bold">{penalties.reduce((sum, p) => sum + p.points, 0)}점</span>
                </div>
            </div>
            
            <div className="overflow-x-auto">
                <table className="min-w-full text-sm text-left">
                    <thead className="bg-gray-50 text-slate-500 font-medium border-b border-gray-200">
                        <tr>
                            <th className="px-6 py-4">발생 일자</th>
                            <th className="px-6 py-4">교시</th>
                            <th className="px-6 py-4">벌점</th>
                            <th className="px-6 py-4">사유</th>
                            <th className="px-6 py-4 text-center">상태 / 처리</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                        {penalties.length === 0 ? (
                            <tr>
                                <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                                    벌점 내역이 깨끗합니다. 훌륭해요!
                                </td>
                            </tr>
                        ) : (
                            penalties.map(item => (
                                <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                                    <td className="px-6 py-4 text-slate-700">{item.date}</td>
                                    <td className="px-6 py-4 text-slate-700">{item.period}</td>
                                    <td className="px-6 py-4 font-bold text-red-500">-{item.points}</td>
                                    <td className="px-6 py-4 text-slate-600">{item.reason}</td>
                                    <td className="px-6 py-4 text-center">
                                        {item.status === 'required' && (
                                            <button 
                                                onClick={() => openRequestModal(item)}
                                                className="bg-brand-blue text-white px-3 py-1.5 rounded hover:bg-blue-700 text-xs font-bold shadow-sm"
                                            >
                                                요청하기
                                            </button>
                                        )}
                                        {item.status === 'pending' && (
                                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                                승인 대기
                                            </span>
                                        )}
                                        {item.status === 'approved' && (
                                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                처리 완료
                                            </span>
                                        )}
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>

            {/* Penalty Request Modal */}
            {isModalOpen && selectedPenalty && (
                <PenaltyRequestModal 
                    penalty={selectedPenalty} 
                    config={user.penaltyConfig} 
                    onClose={() => setIsModalOpen(false)} 
                    onSubmit={handlePenaltySubmit}
                />
            )}
        </div>
    );
};

const PenaltyRequestModal: React.FC<{ 
    penalty: PenaltyHistoryItem, 
    config?: PenaltyConfig, 
    onClose: () => void,
    onSubmit: (file: File | null) => void
}> = ({ penalty, config, onClose, onSubmit }) => {
    const [file, setFile] = useState<File | null>(null);
    const method = config?.method || 'fine'; // Default to fine
    const amount = config?.amountPerPoint || 3000;
    const customText = config?.customDutyText || '지정된 의무';

    const renderContent = () => {
        switch(method) {
            case 'fine':
                const totalFine = penalty.points * amount;
                return (
                    <>
                        <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 mb-4">
                            <p className="text-sm text-slate-600">납부하실 금액</p>
                            <p className="text-2xl font-bold text-brand-blue mt-1">{totalFine.toLocaleString()}원</p>
                            <p className="text-xs text-slate-500 mt-2">
                                (벌점 {penalty.points}점 × {amount.toLocaleString()}원)
                            </p>
                        </div>
                        <div className="mb-4">
                            <p className="text-sm font-bold text-slate-700 mb-2">결제 증빙 업로드</p>
                            <p className="text-xs text-slate-500 mb-2">계좌이체 내역 캡쳐 화면 등을 업로드해주세요.</p>
                        </div>
                    </>
                );
            case 'apology':
                return (
                    <>
                        <div className="mb-4 text-center">
                            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                                <span className="text-2xl">📝</span>
                            </div>
                            <h4 className="font-bold text-slate-700">반성문 제출</h4>
                            <p className="text-sm text-slate-500 mt-1">
                                자필로 작성한 반성문을 촬영하여 업로드해주세요.<br/>
                                (A4용지 1/2 이상, 구체적인 개선 계획 포함)
                            </p>
                        </div>
                    </>
                );
            case 'custom':
                return (
                    <>
                        <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-100 mb-4">
                            <p className="text-sm text-slate-600">수행해야 할 의무</p>
                            <p className="text-lg font-bold text-indigo-700 mt-1">"{customText}"</p>
                        </div>
                        <p className="text-sm text-slate-500 mb-2">위 의무를 수행했음을 증명하는 사진을 업로드해주세요.</p>
                    </>
                );
        }
    };

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6" onClick={e => e.stopPropagation()}>
                <h3 className="text-xl font-bold text-brand-navy mb-4">벌점 처리 요청</h3>
                
                {renderContent()}

                <div className="mb-6">
                    <input 
                        type="file" 
                        accept="image/*"
                        onChange={(e) => setFile(e.target.files ? e.target.files[0] : null)}
                        className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-brand-blue file:text-white hover:file:bg-blue-700 cursor-pointer bg-gray-50 rounded-lg border border-gray-200"
                    />
                </div>

                <div className="flex justify-end gap-2">
                    <button onClick={onClose} className="px-4 py-2 text-slate-600 font-bold text-sm hover:bg-gray-100 rounded-lg">취소</button>
                    <button 
                        onClick={() => onSubmit(file)}
                        className="px-4 py-2 bg-brand-blue text-white font-bold text-sm rounded-lg hover:shadow-lg disabled:opacity-50"
                    >
                        제출하기
                    </button>
                </div>
            </div>
        </div>
    );
};


// 4. Dashboard Requests
const DashboardRequests: React.FC<{ user: User }> = ({ user }) => {
    const [requests, setRequests] = useState<RequestItem[]>([]);
    const [isFormOpen, setIsFormOpen] = useState(false);
    
    // Form States
    const [reqType, setReqType] = useState<'urgent_leave' | 'schedule_change' | 'other'>('urgent_leave');
    const [reqDate, setReqDate] = useState('');
    const [reqReason, setReqReason] = useState('');
    const [reqDetails, setReqDetails] = useState('');

    // Validation Rule: Max 2 per month
    const currentMonthRequests = requests.filter(r => {
        const rDate = new Date(r.requestDate);
        const now = new Date();
        return rDate.getMonth() === now.getMonth() && rDate.getFullYear() === now.getFullYear();
    }).length;

    const canRequest = currentMonthRequests < 2;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!canRequest) {
            alert("월 2회 요청 한도를 초과했습니다.");
            return;
        }
        
        // Mock Add
        const newReq: RequestItem = {
            id: `req-${Date.now()}`,
            type: reqType,
            date: reqDate,
            details: reqDetails,
            reason: reqReason,
            requestDate: new Date().toISOString().split('T')[0],
            status: 'pending'
        };
        setRequests([newReq, ...requests]);
        setIsFormOpen(false);
        // Reset form
        setReqDetails(''); setReqReason(''); setReqDate('');
    };

    return (
        <div className="space-y-6 animate-fade-in">
            {/* Header & Action */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div>
                    <h2 className="text-lg font-bold text-brand-navy">요청 내역</h2>
                    <p className="text-sm text-slate-500 mt-1">
                        이번 달 남은 요청 횟수: <span className={`font-bold ${canRequest ? 'text-green-600' : 'text-red-600'}`}>{2 - currentMonthRequests}회</span> / 2회
                    </p>
                </div>
                <button 
                    onClick={() => setIsFormOpen(true)}
                    disabled={!canRequest}
                    className="mt-4 md:mt-0 bg-brand-blue text-white px-4 py-2 rounded-lg text-sm font-bold hover:shadow-md disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                    + 새로운 요청 작성
                </button>
            </div>

            {/* Request Form */}
            {isFormOpen && (
                <div className="bg-white p-6 rounded-xl shadow-md border border-blue-100 animate-slide-down">
                    <h3 className="font-bold text-slate-800 mb-4 border-b pb-2">새 요청 작성</h3>
                    <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 mb-1">요청 종류</label>
                            <select className="w-full p-2 border rounded text-sm" value={reqType} onChange={(e) => setReqType(e.target.value as any)}>
                                <option value="urgent_leave">긴급 휴무</option>
                                <option value="schedule_change">일정 변경</option>
                                <option value="other">기타</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 mb-1">신청 일자</label>
                            <input type="date" required className="w-full p-2 border rounded text-sm" value={reqDate} onChange={e => setReqDate(e.target.value)} />
                            <p className="text-[10px] text-red-500 mt-1">* 최소 전날 통보 필수</p>
                        </div>
                        <div className="md:col-span-2">
                            <label className="block text-xs font-bold text-slate-500 mb-1">요청 사항</label>
                            <input type="text" placeholder="예: 1교시 제외 요청" required className="w-full p-2 border rounded text-sm" value={reqDetails} onChange={e => setReqDetails(e.target.value)} />
                        </div>
                         <div className="md:col-span-2">
                            <label className="block text-xs font-bold text-slate-500 mb-1">상세 사유</label>
                            <textarea placeholder="사유를 구체적으로 적어주세요." required className="w-full p-2 border rounded text-sm h-20 resize-none" value={reqReason} onChange={e => setReqReason(e.target.value)} />
                        </div>
                        <div className="md:col-span-2 flex justify-end gap-2 pt-2">
                            <button type="button" onClick={() => setIsFormOpen(false)} className="px-4 py-2 text-slate-600 text-sm font-bold hover:bg-gray-100 rounded">취소</button>
                            <button type="submit" className="px-4 py-2 bg-brand-navy text-white text-sm font-bold rounded hover:opacity-90">제출하기</button>
                        </div>
                    </form>
                </div>
            )}

            {/* Table */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="min-w-full text-sm text-left">
                        <thead className="bg-gray-50 text-slate-500 font-medium border-b border-gray-200">
                            <tr>
                                <th className="px-6 py-4">신청일</th>
                                <th className="px-6 py-4">종류</th>
                                <th className="px-6 py-4">요청 사항</th>
                                <th className="px-6 py-4">대상 날짜</th>
                                <th className="px-6 py-4">상태</th>
                                <th className="px-6 py-4">관리자 노트</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {requests.length === 0 ? (
                                <tr><td colSpan={6} className="px-6 py-12 text-center text-slate-400">요청 내역이 없습니다.</td></tr>
                            ) : (
                                requests.map(r => (
                                    <tr key={r.id} className="hover:bg-slate-50">
                                        <td className="px-6 py-4 text-slate-600">{r.requestDate}</td>
                                        <td className="px-6 py-4 font-medium text-slate-800">
                                            {r.type === 'urgent_leave' ? '긴급 휴무' : r.type === 'schedule_change' ? '일정 변경' : '기타'}
                                        </td>
                                        <td className="px-6 py-4 text-slate-600 truncate max-w-xs">{r.details}</td>
                                        <td className="px-6 py-4 text-slate-600">{r.date}</td>
                                        <td className="px-6 py-4">
                                            {r.status === 'pending' && <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-bold">승인 대기</span>}
                                            {r.status === 'approved' && <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-bold">승인됨</span>}
                                            {r.status === 'rejected' && <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-bold">거절됨</span>}
                                        </td>
                                        <td className="px-6 py-4 text-slate-400 italic">{r.adminNote || '-'}</td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};


// --- Main Page Component ---

const MyPage: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'home' | 'schedule' | 'penalty' | 'requests'>('home');
  const [userData, setUserData] = useState<User | null>(user);
  const db = getFirestore();

  // Sync user data manually if needed
  useEffect(() => {
      setUserData(user);
  }, [user]);

  const refreshUser = async () => {
      if(user?.id) {
          const snap = await getDoc(doc(db, 'users', user.id));
          if(snap.exists()) setUserData({id: user.id, ...snap.data()} as User);
      }
  }

  if (!userData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-brand-navy">로그인이 필요합니다</h1>
          <p className="mt-2 text-slate-500">서비스를 이용하시려면 로그인을 해주세요.</p>
        </div>
      </div>
    );
  }

  if (!userData.approved) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
         <div className="bg-white p-8 rounded-xl shadow-lg text-center max-w-md">
            <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">⏳</div>
            <h1 className="text-2xl font-bold text-brand-navy">승인 대기 중</h1>
            <p className="mt-2 text-slate-600 leading-relaxed">관리자의 승인 후 서비스를 이용할 수 있습니다.<br/>잠시만 기다려주세요.</p>
         </div>
      </div>
    );
  }

  // --- Sidebar Component ---
  const SidebarItem = ({ id, label, icon }: { id: typeof activeTab, label: string, icon: React.ReactNode }) => (
    <button 
        onClick={() => setActiveTab(id)}
        className={`w-full flex items-center px-6 py-4 text-sm font-semibold transition-colors border-l-4
            ${activeTab === id 
                ? 'bg-slate-800 border-brand-blue text-white' 
                : 'border-transparent text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
    >
        <span className="mr-3">{icon}</span>
        {label}
    </button>
  );

  return (
    <div className="flex min-h-screen bg-[#F0F2F5] font-sans">
        {/* Sticky Sidebar: Stays fixed relative to viewport as you scroll, but pushes footer naturally */}
        <aside className="w-64 bg-[#1A233A] flex-shrink-0 hidden lg:flex flex-col sticky top-[73px] h-[calc(100vh-73px)] z-10">
            <div className="p-6 border-b border-slate-700">
                <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-brand-blue flex items-center justify-center text-white font-bold text-xl">
                        {userData.name.charAt(0)}
                    </div>
                    <div>
                        <div className="text-white font-bold truncate w-32">{userData.name}</div>
                        <div className="text-xs text-slate-400">{userData.email}</div>
                    </div>
                </div>
            </div>
            <nav className="flex-grow py-6 space-y-1 overflow-y-auto">
                <SidebarItem id="home" label="홈" icon={<HomeIcon />} />
                <SidebarItem id="schedule" label="주간 스케줄" icon={<CalendarIcon />} />
                <SidebarItem id="penalty" label="상벌 내역" icon={<ClipboardIcon />} />
                <SidebarItem id="requests" label="요청하기" icon={<HandRaisedIcon />} />
            </nav>
            <div className="p-6 border-t border-slate-700 text-center text-xs text-slate-500">
                © Morip Lab Corp.
            </div>
        </aside>

        {/* Mobile/Tablet Header for Navigation (Visible only on smaller screens) */}
        <div className="lg:hidden w-full fixed top-[60px] z-10 bg-[#1A233A] text-white overflow-x-auto flex whitespace-nowrap px-4 py-2 gap-4">
             <button onClick={() => setActiveTab('home')} className={`px-3 py-1 rounded-full text-sm ${activeTab === 'home' ? 'bg-brand-blue' : ''}`}>홈</button>
             <button onClick={() => setActiveTab('schedule')} className={`px-3 py-1 rounded-full text-sm ${activeTab === 'schedule' ? 'bg-brand-blue' : ''}`}>주간 스케줄</button>
             <button onClick={() => setActiveTab('penalty')} className={`px-3 py-1 rounded-full text-sm ${activeTab === 'penalty' ? 'bg-brand-blue' : ''}`}>상벌 내역</button>
             <button onClick={() => setActiveTab('requests')} className={`px-3 py-1 rounded-full text-sm ${activeTab === 'requests' ? 'bg-brand-blue' : ''}`}>요청하기</button>
        </div>

        {/* Main Content Area: Natural scroll flow */}
        <main className="flex-grow p-6 lg:p-10 pt-20 lg:pt-10">
            <div className="max-w-7xl mx-auto">
                {activeTab === 'home' && <DashboardHome user={userData} />}
                {activeTab === 'schedule' && <DashboardSchedule user={userData} refreshUser={refreshUser} />}
                {activeTab === 'penalty' && <DashboardPenalty user={userData} />}
                {activeTab === 'requests' && <DashboardRequests user={userData} />}
            </div>
        </main>

        <style>{`
            .animate-fade-in { animation: fadeIn 0.5s ease-out; }
            .animate-slide-down { animation: slideDown 0.3s ease-out; }
            @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
            @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        `}</style>
    </div>
  );
};

export default MyPage;
