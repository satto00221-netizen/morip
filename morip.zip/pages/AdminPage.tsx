import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../hooks/useAuth';
import { User, WeeklyPenalties } from '../types';
import { getFirestore, collection, getDocs, doc, setDoc } from 'firebase/firestore';
import { Link } from 'react-router-dom';
import { DEFAULT_TIMETABLE } from '../constants';

const db = getFirestore();

const AdminPage: React.FC = () => {
  const { user } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [isResetting, setIsResetting] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [stats, setStats] = useState({ total: 0, submitted: 0 });

  const fetchUsers = async () => {
    setLoading(true);
    const usersCollection = collection(db, 'users');
    const userSnapshot = await getDocs(usersCollection);
    const userList = userSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as User));
    
    setStats({
      total: userList.length,
      submitted: 0, // This is a placeholder as calculating it is complex
    });
    
    setUsers(userList);
    setLoading(false);
  };

  useEffect(() => {
    fetchUsers();
  }, []);
  
  const handleResetAllPenalties = async () => {
    setIsResetting(true);
    try {
      const usersCollection = collection(db, 'users');
      const userSnapshot = await getDocs(usersCollection);
      
      if (userSnapshot.empty) {
        alert("초기화할 사용자가 없습니다.");
        setIsResetting(false);
        return;
      }

      const zeroPenalties: WeeklyPenalties = {};
      const days = ['월', '화', '수', '목', '금', '토', '일'];
      days.forEach(day => {
        DEFAULT_TIMETABLE.forEach(slot => {
          if (slot.isStudy) {
            const key = `${day}-${slot.period}`;
            zeroPenalties[key] = 0;
          }
        });
      });

      // Use Promise.all to handle individual updates. This is more robust than a single batch write.
      const updatePromises = userSnapshot.docs.map(userDoc => {
        const penaltyRef = doc(db, 'users', userDoc.id, 'weeklyplan', 'penalty');
        return setDoc(penaltyRef, zeroPenalties);
      });

      await Promise.all(updatePromises);
      
      alert('모든 회원의 주간 벌점이 성공적으로 초기화되었습니다.');
    } catch (error) {
      console.error("벌점 초기화 중 오류 발생:", error);
      alert(`벌점 초기화에 실패했습니다. 오류: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setIsResetting(false);
    }
  };
  
  const filteredUsers = useMemo(() => {
    if (!searchTerm) return users;
    return users.filter(u => 
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      u.email.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [users, searchTerm]);

  if (!user || user.isAdmin !== 1) {
    return (
      <div className="container mx-auto px-6 py-16 text-center">
        <h1 className="text-3xl font-bold text-brand-navy">접근 권한 없음</h1>
        <p className="mt-4 text-brand-gray">관리자만 이 페이지에 접근할 수 있습니다.</p>
      </div>
    );
  }

  return (
    <div className="py-12 bg-brand-bg">
      <div className="container mx-auto px-6">
        <h1 className="text-3xl font-bold text-brand-navy mb-8">관리자 페이지</h1>

        {/* Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-white p-6 rounded-lg shadow-md"><h4 className="text-gray-500">총 회원 수</h4><p className="text-3xl font-bold text-brand-navy">{stats.total}</p></div>
            <div className="bg-white p-6 rounded-lg shadow-md"><h4 className="text-gray-500">시간표 제출</h4><p className="text-3xl font-bold text-brand-navy">N/A</p></div>
        </div>
        
        {/* Controls */}
        <div className="mb-6 flex flex-col md:flex-row gap-4 justify-between items-center bg-white p-4 rounded-lg shadow-md">
            <input 
                type="text" 
                placeholder="이름 또는 이메일로 검색..." 
                className="px-4 py-2 border rounded-md w-full md:w-1/3"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
            />
            <button 
                onClick={handleResetAllPenalties}
                disabled={isResetting || loading}
                className="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 transition-colors w-full md:w-auto disabled:opacity-50 disabled:cursor-wait"
            >
                {isResetting ? '초기화 중...' : '모든 회원 벌점 초기화'}
            </button>
        </div>

        {/* User Table */}
        <div className="bg-white rounded-lg shadow-md overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-100">
              <tr>
                <th className="p-3 text-left text-brand-charcoal font-semibold">이름</th>
                <th className="p-3 text-left text-brand-charcoal font-semibold">이메일</th>
                <th className="p-3 text-center text-brand-charcoal font-semibold">이용 만료일</th>
                <th className="p-3 text-center text-brand-charcoal font-semibold">서비스 상태</th>
                <th className="p-3 text-center text-brand-charcoal font-semibold">시간표 수정</th>
                <th className="p-3 text-center text-brand-charcoal font-semibold">회원 관리</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="text-center p-4 text-brand-charcoal">사용자 목록을 불러오는 중...</td></tr>
              ) : (
                filteredUsers.map(u => (
                  <tr key={u.id} className="border-t">
                    <td className="p-3 font-medium text-brand-charcoal">{u.name}</td>
                    <td className="p-3 text-gray-600">{u.email}</td>
                    <td className="p-3 text-center text-brand-charcoal">{u.membershipEndDate}</td>
                    <td className="p-3 text-center">
                      {u.approved ? 
                        <span className="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">승인됨</span> :
                        <span className="bg-gray-100 text-gray-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">미승인</span>
                      }
                    </td>
                    <td className="p-3 text-center">
                       {u.canEditTimetable === 1 ?
                        <span className="bg-green-100 text-green-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">허용</span> :
                        <span className="bg-gray-100 text-gray-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">불가</span>
                       }
                    </td>
                    <td className="p-3 text-center">
                      <Link to={`/admin/manage/${u.id}`} className="bg-gray-200 text-gray-700 px-3 py-1 text-xs rounded-md hover:bg-gray-300">관리</Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminPage;