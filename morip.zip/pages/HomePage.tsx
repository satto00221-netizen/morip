
import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';

// Icons for "체계적인 온라인 스터디 시스템" section
const VideoCameraIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5l4.72-4.72a.75.75 0 011.28.53v11.38a.75.75 0 01-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 002.25-2.25v-9A2.25 2.25 0 0013.5 5.25h-9A2.25 2.25 0 002.25 7.5v9A2.25 2.25 0 004.5 18.75z" />
    </svg>
);

const BookOpenIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6-2.292m0 0v14.25" />
    </svg>
);

const ShieldCheckIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.286zm0 13.036h.008v.008h-.008v-.008z" />
    </svg>
);

// Icons for '4가지 시스템' (White for Dark Background)
const EyeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.432 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);

const CalendarDaysIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
       <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0H21" />
    </svg>
);

const ScaleIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v17.25m0 0c-1.472 0-2.882.265-4.185.75M12 20.25c1.472 0 2.882.265 4.185.75M18.75 4.97A48.416 48.416 0 0012 4.5c-2.291 0-4.545.16-6.75.47m13.5 0c1.01.143 2.01.317 3 .52m-3-.52l2.62 10.726c.122.499-.106 1.028-.589 1.202a5.988 5.988 0 01-2.131.325 5.988 5.988 0 01-2.131-.325c-.483-.174-.711-.703-.59-1.202L18.75 4.971zm-16.5.52c-1.01.143-2.01.317-3 .52m3-.52L2.62 15.698c-.122.499.106 1.028.589 1.202a5.989 5.989 0 002.131.325 5.989 5.989 0 002.131-.325c.483-.174.711-.703.59-1.202L5.25 4.971z" />
    </svg>
);

const TrophyIcon = () => (
   <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 18.75h-9a9.75 9.75 0 001.5 1.5h6a9.75 9.75 0 001.5-1.5m-9 0a9.75 9.75 0 01-1.5-1.5h12a9.75 9.75 0 01-1.5 1.5m-6-15v9.75m0 0a3.375 3.375 0 110 6.75 3.375 3.375 0 010-6.75zM8.25 12h7.5" />
    </svg>
);

// Colored Icons for 'Detailed Systems' (Blue for White Background)
const EyeIconColor = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-brand-blue mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.432 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);

const CalendarDaysIconColor = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-brand-blue mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
       <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0H21" />
    </svg>
);

const ScaleIconColor = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-brand-blue mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v17.25m0 0c-1.472 0-2.882.265-4.185.75M12 20.25c1.472 0 2.882.265 4.185.75M12 20.25c1.472 0 2.882.265 4.185.75M18.75 4.97A48.416 48.416 0 0012 4.5c-2.291 0-4.545.16-6.75.47m13.5 0c1.01.143 2.01.317 3 .52m-3-.52l2.62 10.726c.122.499-.106 1.028-.589 1.202a5.988 5.988 0 01-2.131.325 5.988 5.988 0 01-2.131-.325c-.483-.174-.711-.703-.59-1.202L18.75 4.971zm-16.5.52c-1.01.143-2.01.317-3 .52m3-.52L2.62 15.698c-.122.499.106 1.028.589 1.202a5.989 5.989 0 002.131.325 5.989 5.989 0 002.131-.325c.483-.174.711-.703.59-1.202L5.25 4.971z" />
    </svg>
);

const TrophyIconColor = () => (
   <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-brand-blue mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 18.75h-9a9.75 9.75 0 001.5 1.5h6a9.75 9.75 0 001.5-1.5m-9 0a9.75 9.75 0 01-1.5-1.5h12a9.75 9.75 0 01-1.5 1.5m-6-15v9.75m0 0a3.375 3.375 0 110 6.75 3.375 3.375 0 010-6.75zM8.25 12h7.5" />
    </svg>
);

const backgroundImages = [
    'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?q=80&w=2573&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    'https://images.unsplash.com/photo-1516321497487-e288fb19713f?q=80&w=2670&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    'https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?q=80&w=2670&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
];

// ScrollReveal Component
const ScrollReveal: React.FC<{ children: React.ReactNode; delay?: string }> = ({ children, delay = '0ms' }) => {
    const [isVisible, setIsVisible] = useState(false);
    const ref = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsVisible(true);
                    observer.unobserve(entry.target);
                }
            },
            { 
                threshold: 0.2, // 애니메이션이 화면의 20%가 보일 때 트리거
                rootMargin: "0px 0px -50px 0px" // 하단에서 50px 정도 더 올라와야 시작
            }
        );

        if (ref.current) {
            observer.observe(ref.current);
        }

        return () => {
            if (ref.current) observer.unobserve(ref.current);
        };
    }, []);

    return (
        <div
            ref={ref}
            className={`transition-all duration-1000 ease-out transform ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-20'}`}
            style={{ transitionDelay: delay }}
        >
            {children}
        </div>
    );
};

const HomePage: React.FC = () => {
    const [currentImageIndex, setCurrentImageIndex] = useState(0);
    const systemSectionRef = useRef<HTMLDivElement>(null);
    const [isSystemSectionVisible, setIsSystemSectionVisible] = useState(false);

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentImageIndex((prevIndex) => (prevIndex + 1) % backgroundImages.length);
        }, 6000); // Change image every 6 seconds

        return () => clearInterval(interval);
    }, []);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsSystemSectionVisible(true);
                    observer.unobserve(entry.target);
                }
            },
            {
                root: null,
                rootMargin: '0px',
                threshold: 0.3, // 0.3으로 높여서 스크롤이 더 내려왔을 때(화면에 더 많이 보일 때) 실행되도록 함
            }
        );

        const currentRef = systemSectionRef.current;
        if (currentRef) {
            observer.observe(currentRef);
        }

        return () => {
            if (currentRef) {
                observer.unobserve(currentRef);
            }
        };
    }, []);

    return (
        <div className="bg-brand-bg">

            {/* Hero Section */}
            <section className="relative text-brand-charcoal py-32 md:py-48 lg:py-60 overflow-hidden">

                {/* Background images */}
                {backgroundImages.map((src, index) => (
                    <div
                        key={index}
                        className={`
                            absolute inset-0 bg-cover bg-center 
                            transition-opacity duration-1000 ease-in-out
                            ${index === currentImageIndex ? 'opacity-100' : 'opacity-0'}
                        `}
                        style={{
                            backgroundImage: `url('${src}')`,
                            animation: index === currentImageIndex ? 'zoom-out 6s linear forwards' : 'none',
                        }}
                    />
                ))}

                {/* Overlay */}
                <div className="absolute inset-0 bg-white/60"></div>

                {/* Content */}
                <div className="container mx-auto px-6 relative z-10">

                    <div className="
                        text-left
                        lg:pl-[100px]
                        xl:pl-[160px]
                        2xl:pl-[220px]
                    ">
            <h1 className="text-6xl sm:text-6xl md:text-6xl lg:text-7xl font-extrabold leading-tight text-brand-charcoal">
                <span className="text-brand-blue">Focus</span> is our work.
            </h1>

            <p className="text-xl sm:text-xl md:text-3xl mt-6 sm:mt-8 lg:mt-10 text-gray-700 font-semibold">
                집에서도 집중할 수 있도록.
            </p>

            <p className="text-lg sm:text-lg md:text-2xl mt-2 md:mt-3 text-gray-700 font-medium max-w-xl">
                수험생, 재택근무자, 프리랜서를 위한 몰입공간.
            </p>


                        <div className="mt-8 md:mt-10 flex gap-4">
                            <button className="bg-brand-blue text-white font-bold 
                                py-3 px-6 md:px-8 rounded-lg border border-brand-blue 
                                hover:shadow-lg hover:opacity-90 transition-all transform hover:scale-105 text-sm md:text-base">
                                지금 시작하기
                            </button>

                            <Link to="/guide"
                                className="bg-transparent text-brand-blue border border-brand-blue 
                                font-bold py-3 px-6 md:px-8 rounded-lg 
                                hover:bg-brand-blue hover:text-white 
                                transition-all transform hover:scale-105 text-sm md:text-base">
                                이용 가이드
                            </Link>
                        </div>
                    </div>

                </div>
            </section>

            {/* Live Study Wall Section */}
            <section className="py-24 bg-white relative overflow-hidden">
                <div className="relative z-10 mx-auto max-w-[1320px] px-6 text-center mb-12">
                    <h2 className="text-xl md:text-xl font-bold text-gray-700 mb-2">
                        전국의 몰입러들이<br className="md:hidden"/> 각자의 자리에서 집중을 이어갑니다.
                    </h2>
                    <p className="text-gray-800 mb-10">오늘도 몰입랩으로 출근하세요.</p>
                </div>

                {/* Vertical Infinite Scroll Container */}
                <div className="relative h-[380px] sm:h-[420px] md:h-[450px] lg:h-[500px] w-full overflow-hidden">
                    {/* Gradient Masks for Fade Effect */}
                    <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-white to-transparent z-20 pointer-events-none"></div>
                    <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-white to-transparent z-20 pointer-events-none"></div>

                    <div className="relative z-10 mx-auto max-w-[1320px] px-4 h-full">
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-8">
                            {/* Column 1 - Scroll Up */}
                            <VerticalMarquee direction="up" speed={55} offset={0} />
                            {/* Column 2 - Scroll Down */}
                            <VerticalMarquee direction="down" speed={65} offset={10} />
                            {/* Column 3 - Scroll Up */}
                            <VerticalMarquee direction="up" speed={60} offset={5} className="hidden md:block" />
                             {/* Column 4 - Scroll Down */}
                            <VerticalMarquee direction="down" speed={70} offset={15} className="hidden md:block" />
                        </div>
                    </div>
                </div>
            </section>

            {/* 몰입을 완성하는 4가지 시스템 Section (Original Grid Restored) */}
            <section className="py-24 bg-brand-bg" ref={systemSectionRef}>
                <div className="container mx-auto px-0 sm:px-8 md:px-8 lg:px-32">
                    <div
                    className="relative text-white rounded-3xl p-12 md:p-16 text-left shadow-xl overflow-hidden"
                    style={{
                        background: 'linear-gradient(180deg, #21316b 0%, #0F172A 100%)', // 남색 → 진남색
                    }}
                    >
                    {/* 도트 패턴 */}
                    <div
                        className="absolute inset-0 opacity-10 pointer-events-none"
                        style={{
                        backgroundImage:
                            'radial-gradient(#ffffff 1px, transparent 1px)',
                        backgroundSize: '24px 24px',
                        }}
                    ></div>

                    <div className="relative z-10">
                        <p className="text-base font-bold text-blue-300 uppercase tracking-wider mb-2 leading-tight">
                        WHY MORIP LAB
                        </p>
                        <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-6 leading-snug">
                        몰입을 완성하는 4가지 시스템
                        </h2>
                        <p className="text-lg text-gray-200 mb-16 max-w-2xl leading-snug">
                        전담 관리부터 순위 공개까지, 몰입랩은 당신의 집중을 관리합니다.
                        </p>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
                        {[
                            { icon: <EyeIcon />, title: '관리자의 실시간 모니터링', description: '전담 관리자가 실시간으로 출석과 태도를 점검하며, 모든 학습자가 긴장감 속에 몰입할 수 있도록 관리합니다.', delay: '0ms' },
                            { icon: <CalendarDaysIcon />, title: '주간계획표 기반 개별관리', description: '매주 제출하는 주간계획표를 기반으로 각자의 루틴에 맞춘 맞춤형 학습 관리를 제공합니다.', delay: '150ms' },
                            { icon: <ScaleIcon />, title: '상벌·처벌을 통한 동기부여', description: '불성실한 태도는 즉시 경고와 처벌, 성실한 참여는 보상으로 이어집니다. 규칙이 있는 환경이 몰입의 기본입니다.', delay: '300ms' },
                            { icon: <TrophyIcon />, title: '순위 공개 및 보상', description: '매일 공개되는 몰입 순위와 보상을 통해 경쟁 속에서도 성장의 동기를 얻을 수 있습니다.', delay: '450ms' },
                        ].map((item, index) => (
                            <div
                            key={index}
                            // 애니메이션 거리 증가 (translate-y-8 -> translate-y-20)
                            className={`transition-all duration-1000 ease-out ${isSystemSectionVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-50'}`}
                            style={{ transitionDelay: item.delay }}
                            >
                            <div className="bg-white/10 backdrop-blur-sm p-5 rounded-lg mb-6 inline-block">
                                {item.icon}
                            </div>
                            <h3 className="text-2xl font-semibold text-white mb-3">
                                {item.title}
                            </h3>
                            <p className="text-base md:text-lg text-gray-200 leading-relaxed">
                                {item.description}
                            </p>
                            </div>
                        ))}
                        </div>
                    </div>
                    </div>
                </div>
            </section>

            {/* 몰입을 완성하는 4가지 시스템 Detailed Section (New Added Below) */}
            <section className="py-24 bg-white">
                {/* 좌우 여백 증가: px-6 md:px-16 lg:px-24 xl:px-48 */}
                <div className="container mx-auto px-6 md:px-16 lg:px-20 xl:px-48">
                    <div className="space-y-32">
                        {/* Section 1: Text Left, Image Right */}
                        <ScrollReveal>
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                                <div className="order-1">
                                    <EyeIconColor />
                                    <h3 className="text-3xl font-bold text-brand-navy mb-4">
                                        관리자의 실시간 모니터링
                                    </h3>
                                    <p className="text-lg text-brand-gray leading-relaxed">
                                        전담 관리자가 실시간으로 출석과 태도를 점검합니다. 
                                        잠깐의 딴짓도 허용되지 않는 긴장감 속에서, 
                                        모든 학습자가 최고의 몰입 상태를 유지할 수 있도록 돕습니다.
                                    </p>
                                </div>
                                <div className="order-2">
                                    <div className="rounded-2xl overflow-hidden shadow-2xl hover:shadow-3xl transition-shadow duration-300">
                                        <img 
                                            src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2670&auto=format&fit=crop" 
                                            alt="Real-time monitoring" 
                                            className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-700"
                                        />
                                    </div>
                                </div>
                            </div>
                        </ScrollReveal>

                        {/* Section 2: Image Left, Text Right */}
                        <ScrollReveal>
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                                <div className="order-2 lg:order-1">
                                    <div className="rounded-2xl overflow-hidden shadow-2xl hover:shadow-3xl transition-shadow duration-300">
                                        <img 
                                            src="https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?q=80&w=2672&auto=format&fit=crop" 
                                            alt="Weekly Planning" 
                                            className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-700"
                                        />
                                    </div>
                                </div>
                                <div className="order-1 lg:order-2">
                                    <CalendarDaysIconColor />
                                    <h3 className="text-3xl font-bold text-brand-navy mb-4">
                                        주간계획표 기반 개별관리
                                    </h3>
                                    <p className="text-lg text-brand-gray leading-relaxed">
                                        매주 제출하는 주간계획표를 기반으로 각자의 루틴에 맞춘 맞춤형 학습 관리를 제공합니다.
                                        스스로 설정한 목표를 달성하며 성취감을 느껴보세요.
                                    </p>
                                </div>
                            </div>
                        </ScrollReveal>

                        {/* Section 3: Text Top, Image Bottom */}
                        <ScrollReveal>
                            <div className="flex flex-col items-center text-center">
                                <div className="max-w-3xl mb-12">
                                    <div className="flex justify-center"><ScaleIconColor /></div>
                                    <h3 className="text-3xl font-bold text-brand-navy mb-4">
                                        상벌·처벌을 통한 동기부여
                                    </h3>
                                    <p className="text-lg text-brand-gray leading-relaxed">
                                        불성실한 태도는 즉시 경고와 처벌, 성실한 참여는 보상으로 이어집니다. 
                                        규칙이 있는 환경이 몰입의 기본입니다. 엄격하지만 확실한 성장을 약속합니다.
                                    </p>
                                </div>
                                <div className="w-full max-w-5xl rounded-2xl overflow-hidden shadow-2xl hover:shadow-3xl transition-shadow duration-300">
                                    <img 
                                        src="https://images.unsplash.com/photo-1434030216411-0b793f4b4173?q=80&w=2670&auto=format&fit=crop" 
                                        alt="Strict Rules and Motivation" 
                                        className="w-full h-[400px] lg:h-[500px] object-cover transform hover:scale-105 transition-transform duration-700"
                                    />
                                </div>
                            </div>
                        </ScrollReveal>

                        {/* Section 4: Image Left, Text Right */}
                        <ScrollReveal>
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                                <div className="order-2 lg:order-1">
                                    <div className="rounded-2xl overflow-hidden shadow-2xl hover:shadow-3xl transition-shadow duration-300">
                                        <img 
                                            src="https://images.unsplash.com/photo-1565514020176-dbf22779a26f?q=80&w=2670&auto=format&fit=crop" 
                                            alt="Ranking and Rewards" 
                                            className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-700"
                                        />
                                    </div>
                                </div>
                                <div className="order-1 lg:order-2">
                                    <TrophyIconColor />
                                    <h3 className="text-3xl font-bold text-brand-navy mb-4">
                                        순위 공개 및 보상
                                    </h3>
                                    <p className="text-lg text-brand-gray leading-relaxed">
                                        매일 공개되는 몰입 순위와 보상을 통해 경쟁 속에서도 성장의 동기를 얻을 수 있습니다.
                                        선의의 경쟁은 당신을 더 높은 곳으로 이끌어줍니다.
                                    </p>
                                </div>
                            </div>
                        </ScrollReveal>
                    </div>
                </div>
            </section>

            {/* 체계적인 온라인 스터디 시스템 Section */}
            <section className="py-16 md:py-24 bg-white">
                <div className="container mx-auto px-6">
                    <div className="text-center mb-16">
                        <h2 className="text-3xl md:text-4xl font-bold text-brand-navy">체계적인 온라인 스터디 시스템</h2>
                        <p className="mt-4 text-lg text-brand-gray max-w-3xl mx-auto">몰입랩은 최고의 몰입 환경을 제공합니다.</p>
                    </div>
                    <div className="grid md:grid-cols-3 gap-8">
                        <div className="bg-white p-8 rounded-lg border border-gray-200 shadow-lg flex flex-col items-center text-center transition-transform transform hover:-translate-y-2">
                            <div className="bg-blue-100 p-4 rounded-full mb-6">
                               <VideoCameraIconColor />
                            </div>
                            <h3 className="text-xl font-semibold text-brand-navy mb-2">웹캠 기반 스터디</h3>
                            <p className="text-brand-gray leading-relaxed">Microsoft Teams를 통한 실시간 웹캠 스터디로 현장감 있는 학습 분위기를 조성하고, 서로의 공부 모습을 보며 동기를 부여받습니다.</p>
                        </div>
                        <div className="bg-white p-8 rounded-lg border border-gray-200 shadow-lg flex flex-col items-center text-center transition-transform transform hover:-translate-y-2">
                            <div className="bg-blue-100 p-4 rounded-full mb-6">
                                <BookOpenIconColor />
                            </div>
                            <h3 className="text-xl font-semibold text-brand-navy mb-2">체계적인 시간표</h3>
                            <p className="text-brand-gray leading-relaxed">대학 시간표와 유사한 체계적인 스케줄을 통해 규칙적인 생활 습관을 형성하고, 순수 공부 시간을 극대화할 수 있도록 돕습니다.</p>
                        </div>
                        <div className="bg-white p-8 rounded-lg border border-gray-200 shadow-lg flex flex-col items-center text-center transition-transform transform hover:-translate-y-2">
                            <div className="bg-blue-100 p-4 rounded-full mb-6">
                                <ShieldCheckIconColor />
                            </div>
                            <h3 className="text-xl font-semibold text-brand-navy mb-2">엄격한 규칙</h3>
                            <p className="text-brand-gray leading-relaxed">출결, 지각, 학습 태도에 대한 명확한 규정을 적용하여 모든 구성원이 공부에만 집중할 수 있는 면학 분위기를 유지합니다.</p>
                        </div>
                    </div>
                </div>
            </section>

            
            {/* 참여 방법 Section */}
            <section className="py-16 md:py-24 bg-brand-bg">
                <div className="container mx-auto px-6">
                    <div className="text-center mb-16">
                        <h2 className="text-3xl md:text-4xl font-bold text-brand-navy">참여 방법</h2>
                        <p className="mt-4 text-lg text-brand-gray max-w-3xl mx-auto">간단한 4단계로 몰입랩에 합류하세요.</p>
                    </div>
                    <div className="relative max-w-5xl mx-auto">
                        <div className="absolute top-8 left-0 w-full h-0.5 bg-blue-200 hidden md:block" aria-hidden="true"></div>
                        <div className="relative grid md:grid-cols-4 gap-8 text-center">
                            
                            <div className="flex flex-col items-center">
                                <div className="p-1 mb-4 rounded-full bg-gradient-to-br from-gradient-start to-gradient-end z-10 shadow-lg">
                                  <div className="w-14 h-14 rounded-full bg-white text-brand-blue flex items-center justify-center font-bold text-2xl">1</div>
                                </div>
                                <h3 className="text-xl font-semibold text-brand-navy mb-2">회원가입</h3>
                                <p className="text-brand-gray px-2 leading-relaxed">사이트에 가입하여 바로 활동을 시작하세요.</p>
                            </div>
                            
                            <div className="flex flex-col items-center">
                                <div className="p-1 mb-4 rounded-full bg-gradient-to-br from-gradient-start to-gradient-end z-10 shadow-lg">
                                  <div className="w-14 h-14 rounded-full bg-white text-brand-blue flex items-center justify-center font-bold text-2xl">2</div>
                                </div>
                                <h3 className="text-xl font-semibold text-brand-navy mb-2">시간표 제출</h3>
                                <p className="text-brand-gray px-2 leading-relaxed">매주 월요일까지 주간 공부 계획을 제출합니다.</p>
                            </div>
                            
                            <div className="flex flex-col items-center">
                                <div className="p-1 mb-4 rounded-full bg-gradient-to-br from-gradient-start to-gradient-end z-10 shadow-lg">
                                  <div className="w-14 h-14 rounded-full bg-white text-brand-blue flex items-center justify-center font-bold text-2xl">3</div>
                                </div>
                                <h3 className="text-xl font-semibold text-brand-navy mb-2">Teams 접속</h3>
                                <p className="text-brand-gray px-2 leading-relaxed">예정된 시간에 맞춰 Microsoft Teams에 접속합니다.</p>
                            </div>

                            <div className="flex flex-col items-center">
                                <div className="p-1 mb-4 rounded-full bg-gradient-to-br from-gradient-start to-gradient-end z-10 shadow-lg">
                                  <div className="w-14 h-14 rounded-full bg-white text-brand-blue flex items-center justify-center font-bold text-2xl">4</div>
                                </div>
                                <h3 className="text-xl font-semibold text-brand-navy mb-2">학습 시작</h3>
                                <p className="text-brand-gray px-2 leading-relaxed">최고의 면학 분위기 속에서 공부에 집중합니다.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            
             <style>{`
                @keyframes marquee-up {
                    0% { transform: translateY(0); }
                    100% { transform: translateY(-50%); }
                }
                @keyframes marquee-down {
                    0% { transform: translateY(-50%); }
                    100% { transform: translateY(0); }
                }
                .animate-marquee-up {
                    animation: marquee-up 40s linear infinite;
                }
                .animate-marquee-down {
                    animation: marquee-down 40s linear infinite;
                }
            `}</style>
        </div>
    );
};

const localImages = Array.from({ length: 22 }).map((_, i) =>
  `https://raw.githubusercontent.com/satto00221-netizen/morip/main/${i + 1}.jpg`
);


// Sub-components for the Vertical Marquee
interface VerticalMarqueeProps {
    direction: 'up' | 'down';
    speed: number;
    offset: number;
    className?: string;
}
const VerticalMarquee: React.FC<VerticalMarqueeProps> = ({ direction, speed, offset, className }) => {

    const users = React.useMemo(() => (
        Array.from({ length: 10 }).map((_, i) => ({
            id: i,
            name: `User ${Math.floor(Math.random() * 9000) + 1000}`,
            time: `${String(Math.floor(Math.random() * 12)).padStart(2, '0')}:${String(Math.floor(Math.random() * 60)).padStart(2, '0')}:${String(Math.floor(Math.random() * 60)).padStart(2, '0')}`,
            img: localImages[Math.floor(Math.random() * localImages.length)]
        }))
    ), []); // ← 빈 배열 = 최초 1번만 실행됨

    const displayUsers = [...users, ...users];

    return (
        <div className={`relative min-h-full overflow-hidden ${className}`}>
            <div 
                className={`flex flex-col gap-6 sm:gap-10 md:gap-14 ${direction === 'up' ? 'animate-marquee-up' : 'animate-marquee-down'}`}
                style={{ animationDuration: `${speed}s` }}
            >
                {displayUsers.map((user, idx) => (
                    <StudyCard key={`${user.id}-${idx}`} user={user} />
                ))}
            </div>
        </div>
    );
};


const StudyCard: React.FC<{ user: any }> = ({ user }) => (
  <div className="relative 
      w-full 
      max-w-[260px]            /* 카드 최대 크기 축소 */
      mx-auto                  /* 가운데 정렬 */
      aspect-video 
      rounded-xl 
      overflow-hidden 
      shadow-md 
      bg-gray-900 
      group 
      transition-transform 
      duration-300"
  >
        <img 
            src={user.img} 
            alt="study cam" 
            className="w-full h-full object-cover opacity-80 group-hover:opacity-60 transition-opacity" 
        />
        
        {/* UI Overlay */}
        <div className="absolute inset-0 flex flex-col justify-between p-3">
            <div className="flex justify-between items-start">
                <div className="flex items-center space-x-1 bg-red-600/90 text-white text-[10px] font-bold px-2 py-0.5 rounded animate-pulse">
                    <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                    <span>LIVE</span>
                </div>
            </div>
            
            <div className="flex justify-between items-end">
                <div className="text-white">
                    <div className="text-xs font-medium bg-black/40 px-2 py-1 rounded backdrop-blur-sm">
                        {user.name}
                    </div>
                </div>
                <div className="w-6 h-6 rounded-full bg-black/40 flex items-center justify-center backdrop-blur-sm text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3.5 h-3.5">
                        <path d="M10 2a.75.75 0 01.75.75v1.5a.75.75 0 001.5 0v-1.5a2.25 2.25 0 00-2.25-2.25h-.25a2.25 2.25 0 00-2.25 2.25v1.5a.75.75 0 001.5 0v-1.5A.75.75 0 0110 2z" />
                        <path d="M5.5 6a.75.75 0 00-1.5 0v2a.75.75 0 001.5 0V6zM16 6a.75.75 0 00-1.5 0v2a.75.75 0 001.5 0V6z" />
                        <path fillRule="evenodd" d="M3 9.5A1.5 1.5 0 014.5 8h11a1.5 1.5 0 011.5 1.5v4.25a.75.75 0 01-.75.75h-2.3l-1.983 1.513a.75.75 0 01-.934 0L9.05 14.5H6.75a.75.75 0 01-.75-.75V9.5zM10 11a1 1 0 100 2 1 1 0 000-2z" clipRule="evenodd" />
                    </svg>
                     {/* Muted Icon */}
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3.5 h-3.5 text-red-400">
                        <path fillRule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 10c0-2.21-.894-4.208-2.343-5.657a1 1 0 010-1.414zm-2.829 2.828a1 1 0 011.415 0A5.983 5.983 0 0115 10a5.984 5.984 0 01-1.757 4.243 1 1 0 01-1.415-1.415A3.984 3.984 0 0013 10a3.983 3.983 0 00-1.172-2.828 1 1 0 010-1.415z" clipRule="evenodd" />
                    </svg>
                </div>
            </div>
        </div>
    </div>
);


// Colored Icons for bottom section
const VideoCameraIconColor = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5l4.72-4.72a.75.75 0 011.28.53v11.38a.75.75 0 01-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 002.25-2.25v-9A2.25 2.25 0 0013.5 5.25h-9A2.25 2.25 0 002.25 7.5v9A2.25 2.25 0 004.5 18.75z" />
    </svg>
);
const BookOpenIconColor = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6-2.292m0 0v14.25" />
    </svg>
);
const ShieldCheckIconColor = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.286zm0 13.036h.008v.008h-.008v-.008z" />
    </svg>
);


export default HomePage;
