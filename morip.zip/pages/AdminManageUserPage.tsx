
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { User, WeeklyTimetable, WeeklyStatus, StudyStatus } from '../types';
import { DEFAULT_TIMETABLE } from '../constants';
import { getFirestore, doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';

const db = getFirestore();

const AdminManageUserPage: React.FC = () => {
    const { userId } = useParams<{ userId: string }>();
    const [user, setUser] = useState<User | null>(null);
    const [timetable, setTimetable] = useState<WeeklyTimetable>({});
    // Changed from penalties(number) to statuses(string enum)
    const [statuses, setStatuses] = useState<WeeklyStatus>({});
    const [loading, setLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [saveSuccess, setSaveSuccess] = useState(false);
    const [membershipStart, setMembershipStart] = useState('');
    const [membershipEnd, setMembershipEnd] = useState('');
    
    const days = ['월', '화', '수', '목', '금', '토', '일'];

    const fetchData = useCallback(async () => {
        if (!userId) return;
        setLoading(true);
        try {
            const userRef = doc(db, 'users', userId);
            const timetableRef = doc(db, 'users', userId, 'weeklyplan', 'current');
            // Use 'status' document instead of 'penalty' for the new logic
            const statusRef = doc(db, 'users', userId, 'weeklyplan', 'status');

            const [userSnap, timetableSnap, statusSnap] = await Promise.all([
                getDoc(userRef),
                getDoc(timetableRef),
                getDoc(statusRef)
            ]);

            if (userSnap.exists()) {
                const userData = { id: userSnap.id, ...userSnap.data() } as User;
                setUser(userData);
                setMembershipStart(userData.membershipStartDate);
                setMembershipEnd(userData.membershipEndDate);
            }
            setTimetable(timetableSnap.exists() ? timetableSnap.data() as WeeklyTimetable : {});
            setStatuses(statusSnap.exists() ? statusSnap.data() as WeeklyStatus : {});
        } catch (error) {
            console.error("Failed to fetch user data:", error);
        } finally {
            setLoading(false);
        }
    }, [userId]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const handleToggle = async (field: 'approved' | 'canEditTimetable', currentValue: boolean | number) => {
        if (!userId || !user) return;
        const newValue = typeof currentValue === 'boolean' ? !currentValue : (currentValue === 0 ? 1 : 0);
        const userRef = doc(db, 'users', userId);
        try {
            await updateDoc(userRef, { [field]: newValue });
            setUser({ ...user, [field]: newValue });
        } catch (error) {
            console.error(`Failed to update ${field}:`, error);
        }
    };

    const handleSaveMembership = async () => {
        if (!userId) return;
        setIsSaving(true);
        try {
            const userRef = doc(db, 'users', userId);
            await updateDoc(userRef, {
                membershipStartDate: membershipStart,
                membershipEndDate: membershipEnd,
            });
            setUser(prev => prev ? {...prev, membershipStartDate: membershipStart, membershipEndDate: membershipEnd} : null);
            alert('이용 기간이 성공적으로 저장되었습니다.');
        } catch (error) {
            console.error("Failed to save membership dates:", error);
            alert('이용 기간 저장에 실패했습니다.');
        } finally {
            setIsSaving(false);
        }
    };


    const handleStatusChange = (key: string, value: StudyStatus) => {
        setStatuses(prev => ({ ...prev, [key]: value }));
    };
    
    const handleSaveStatuses = async () => {
        if (!userId) return;
        setIsSaving(true);
        const statusRef = doc(db, "users", userId, "weeklyplan", "status");
        try {
            await setDoc(statusRef, statuses);
            setSaveSuccess(true);
            setTimeout(() => setSaveSuccess(false), 2000);
        } catch (error) {
            console.error("Failed to save statuses:", error);
        } finally {
            setIsSaving(false);
        }
    };

    // Helper to get points based on status for display
    const getPoints = (status: StudyStatus) => {
        switch(status) {
            case 'late': return 1;
            case 'absent': return 2;
            default: return 0;
        }
    };

    if (loading) {
        return <div className="container mx-auto px-6 py-16 text-center">로딩 중...</div>;
    }

    if (!user) {
        return <div className="container mx-auto px-6 py-16 text-center">사용자를 찾을 수 없습니다.</div>;
    }

    return (
        <div className="py-12 bg-brand-bg">
            <div className="container mx-auto px-6">
                <div className="mb-8">
                    <Link to="/admin" className="text-brand-blue hover:underline">&larr; 관리자 페이지로 돌아가기</Link>
                    <h1 className="text-3xl font-bold text-brand-navy mt-2">{user.name} <span className="text-lg text-gray-500 font-normal">({user.email})</span></h1>
                </div>

                {/* Controls */}
                <div className="space-y-8">
                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <h3 className="text-xl font-bold text-brand-navy mb-4">권한 설정</h3>
                        <div className="grid md:grid-cols-2 gap-6">
                            <div className="flex items-center justify-between p-4 border rounded-md">
                                <span className="font-semibold text-gray-700">서비스 이용 승인</span>
                                <label className="relative inline-flex items-center cursor-pointer">
                                    <input type="checkbox" checked={user.approved} onChange={() => handleToggle('approved', user.approved)} className="sr-only peer" />
                                    <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-2 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-blue"></div>
                                </label>
                            </div>
                            <div className="flex items-center justify-between p-4 border rounded-md">
                                <span className="font-semibold text-gray-700">시간표 수정 권한 부여</span>
                                <label className="relative inline-flex items-center cursor-pointer">
                                    <input type="checkbox" checked={user.canEditTimetable === 1} onChange={() => handleToggle('canEditTimetable', user.canEditTimetable)} className="sr-only peer" />
                                    <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-2 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-blue"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                     <div className="bg-white p-6 rounded-lg shadow-md">
                        <h3 className="text-xl font-bold text-brand-navy mb-4">서비스 이용 기간 설정</h3>
                        <div className="grid md:grid-cols-2 gap-4 items-end">
                            <div>
                                <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 mb-1">시작일</label>
                                <input type="text" id="startDate" value={membershipStart} onChange={e => setMembershipStart(e.target.value)} placeholder="YYYY.MM.DD" className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue" />
                            </div>
                            <div>
                                <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 mb-1">종료일</label>
                                <input type="text" id="endDate" value={membershipEnd} onChange={e => setMembershipEnd(e.target.value)} placeholder="YYYY.MM.DD" className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue" />
                            </div>
                        </div>
                        <div className="mt-4 flex justify-end">
                            <button onClick={handleSaveMembership} disabled={isSaving} className="bg-brand-navy text-white px-6 py-2 rounded-md hover:bg-opacity-90 transition-all font-semibold disabled:opacity-50">
                                {isSaving ? '저장 중...' : '기간 저장'}
                            </button>
                        </div>
                    </div>
                </div>

                {/* Timetable and Status Form */}
                <div className="bg-white p-8 rounded-lg shadow-lg mt-8">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-2xl font-bold text-brand-navy">주간 시간표 및 벌점 관리</h3>
                        <div className="text-sm text-gray-500 space-x-2">
                            <span className="inline-block w-3 h-3 bg-green-100 border border-green-200 rounded-full"></span> 출석(0점)
                            <span className="inline-block w-3 h-3 bg-yellow-100 border border-yellow-200 rounded-full"></span> 지각(1점)
                            <span className="inline-block w-3 h-3 bg-red-100 border border-red-200 rounded-full"></span> 결석(2점)
                        </div>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="min-w-full border-collapse text-center table-fixed">
                            <thead>
                                <tr className="bg-gray-100">
                                    <th className="p-3 font-semibold text-brand-charcoal border border-brand-light-gray w-[120px]">교시</th>
                                    {days.map(day => (
                                        <th key={day} className="p-3 font-semibold text-brand-charcoal border border-brand-light-gray">{day}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {DEFAULT_TIMETABLE.map(slot => (
                                    <tr key={slot.period} className="border-t border-brand-light-gray">
                                        {slot.isStudy ? (
                                            <>
                                                <td className="p-2 font-semibold text-brand-navy border border-brand-light-gray bg-gray-50 align-middle">
                                                    {slot.period}
                                                </td>
                                                {days.map(day => {
                                                    const key = `${day}-${slot.period}`;
                                                    const isChecked = !!timetable[key];
                                                    const currentStatus = statuses[key] || 'none';
                                                    const currentPoints = getPoints(currentStatus);

                                                    let cellBg = '';
                                                    if (currentStatus === 'attendance') cellBg = 'bg-green-50';
                                                    else if (currentStatus === 'late') cellBg = 'bg-yellow-50';
                                                    else if (currentStatus === 'absent') cellBg = 'bg-red-50';
                                                    else if (isChecked) cellBg = 'bg-blue-50/30';

                                                    return(
                                                    <td key={key} className={`p-2 border border-brand-light-gray align-middle ${cellBg}`}>
                                                        <div className="flex flex-col items-center justify-center gap-1">
                                                            {isChecked ? 
                                                                <span className="text-xs text-blue-600 font-bold mb-1">신청됨</span> :
                                                                <span className="text-xs text-gray-400 mb-1">미신청</span>
                                                            }
                                                            <select
                                                                value={currentStatus}
                                                                onChange={(e) => handleStatusChange(key, e.target.value as StudyStatus)}
                                                                className={`w-full text-xs border rounded p-1 ${
                                                                    currentStatus === 'attendance' ? 'text-green-700 border-green-300 font-bold' :
                                                                    currentStatus === 'late' ? 'text-yellow-700 border-yellow-300 font-bold' :
                                                                    currentStatus === 'absent' ? 'text-red-700 border-red-300 font-bold' :
                                                                    currentStatus === 'off' ? 'text-gray-500 border-gray-300' :
                                                                    'text-gray-400 border-gray-200'
                                                                }`}
                                                            >
                                                                <option value="none">미처리</option>
                                                                <option value="attendance">출석</option>
                                                                <option value="late">지각</option>
                                                                <option value="absent">결석</option>
                                                                <option value="off">휴무</option>
                                                            </select>
                                                            {currentPoints > 0 && (
                                                                <span className="text-xs font-bold text-red-500">+{currentPoints}점</span>
                                                            )}
                                                        </div>
                                                    </td>
                                                )})}
                                            </>
                                        ) : (
                                            <td colSpan={8} className="p-3 font-semibold text-brand-blue bg-blue-50 border border-brand-light-gray">
                                                {slot.period} ({slot.time})
                                            </td>
                                        )}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="mt-8 flex justify-end">
                        <button 
                            onClick={handleSaveStatuses}
                            disabled={isSaving}
                            className="bg-brand-blue text-white px-8 py-3 rounded-md hover:shadow-lg transition-all font-semibold shadow-md disabled:opacity-50"
                        >
                            {isSaving ? '저장 중...' : saveSuccess ? '저장 완료!' : '관리 상태 저장'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AdminManageUserPage;
