import React from 'react';
import { Link } from 'react-router-dom';

const NotFoundPage: React.FC = () => {
  return (
    <div className="flex items-center justify-center min-h-[60vh] bg-white">
      <div className="text-center">
        <h1 className="text-9xl font-extrabold text-brand-navy tracking-widest">404</h1>
        <div className="bg-brand-blue text-white px-2 text-sm rounded rotate-12 absolute">
          페이지를 찾을 수 없음
        </div>
        <p className="mt-4 text-lg text-brand-gray">죄송합니다. 찾으시는 페이지를 발견할 수 없습니다.</p>
        <Link 
          to="/"
          className="mt-8 inline-block bg-gradient-to-r from-gradient-start to-gradient-end text-white font-semibold px-6 py-3 rounded-md hover:shadow-lg transition-shadow"
        >
          홈으로 가기
        </Link>
      </div>
    </div>
  );
};

export default NotFoundPage;